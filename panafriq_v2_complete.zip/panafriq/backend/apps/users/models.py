from django.contrib.auth.models import AbstractUser
from django.db import models
from django.utils import timezone
from django.conf import settings
import uuid, pyotp, random, string


def _generate_otp():
    return ''.join(random.choices(string.digits, k=6))


class User(AbstractUser):
    COUNTRY_CHOICES = [
        ('NG', 'Nigeria'), ('GH', 'Ghana'),
        ('CM', 'Cameroon'), ('OTHER', 'Other'),
    ]
    AUTH_CHOICES = [
        ('email', 'Email/Password'),
        ('google', 'Google SSO'),
        ('facebook', 'Facebook SSO'),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=20, blank=True)
    country = models.CharField(max_length=10, choices=COUNTRY_CHOICES, default='NG')
    date_of_birth = models.DateField(null=True, blank=True)
    profile_picture = models.ImageField(upload_to='profiles/', null=True, blank=True)
    whatsapp_number = models.CharField(max_length=20, blank=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)

    # Verification
    is_verified = models.BooleanField(default=False)
    is_admin = models.BooleanField(default=False)
    email_verified = models.BooleanField(default=False)
    otp_code = models.CharField(max_length=6, blank=True)
    otp_expiry = models.DateTimeField(null=True, blank=True)
    totp_secret = models.CharField(max_length=64, blank=True)  # for TOTP
    totp_enabled = models.BooleanField(default=False)

    # SSO
    auth_provider = models.CharField(max_length=20, choices=AUTH_CHOICES, default='email')
    sso_uid = models.CharField(max_length=255, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username', 'first_name', 'last_name']

    def get_age(self):
        if self.date_of_birth:
            today = timezone.now().date()
            return (today - self.date_of_birth).days // 365
        return None

    def is_old_enough(self):
        age = self.get_age()
        return age is not None and age >= 16

    def generate_otp(self):
        self.otp_code = _generate_otp()
        self.otp_expiry = timezone.now() + timezone.timedelta(
            minutes=settings.OTP_EXPIRY_MINUTES
        )
        self.save(update_fields=['otp_code', 'otp_expiry'])
        return self.otp_code

    def verify_otp(self, code):
        if (self.otp_code == code and
                self.otp_expiry and
                timezone.now() < self.otp_expiry):
            self.email_verified = True
            self.otp_code = ''
            self.otp_expiry = None
            self.save(update_fields=['email_verified', 'otp_code', 'otp_expiry'])
            return True
        return False

    def get_totp_uri(self):
        if not self.totp_secret:
            self.totp_secret = pyotp.random_base32()
            self.save(update_fields=['totp_secret'])
        return pyotp.totp.TOTP(self.totp_secret).provisioning_uri(
            name=self.email, issuer_name='PanAfriq'
        )

    def verify_totp(self, code):
        if not self.totp_secret:
            return False
        totp = pyotp.TOTP(self.totp_secret)
        return totp.verify(code, valid_window=1)

    def __str__(self):
        return f"{self.get_full_name()} ({self.email})"

    class Meta:
        db_table = 'users'


class VoterSession(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    session_token = models.CharField(max_length=255, unique=True)
    ip_address = models.GenericIPAddressField()
    device_fingerprint = models.CharField(max_length=255, blank=True)
    user_agent = models.TextField(blank=True)
    country = models.CharField(max_length=10, blank=True)
    email = models.EmailField(blank=True)
    date_of_birth = models.DateField(null=True, blank=True)
    age_verified = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'voter_sessions'
