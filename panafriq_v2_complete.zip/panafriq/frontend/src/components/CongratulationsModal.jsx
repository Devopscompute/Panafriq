import React from 'react'
import Confetti from './Confetti'

export default function CongratulationsModal({ user, contestant, onClose }) {
  return (
    <>
      <Confetti active={true} duration={5000} />
      <div style={styles.overlay} onClick={onClose}>
        <div style={styles.modal} onClick={e => e.stopPropagation()}>
          <div style={styles.flowers}>🌸 🌺 🌼 🌻 🌹</div>
          <div style={styles.trophy}>🏆</div>
          <h2 style={styles.title}>Congratulations!</h2>
          <p style={styles.name}>{user?.first_name} {user?.last_name}</p>
          <p style={styles.msg}>You are now officially registered as a PanAfriq contestant!</p>

          {contestant && (
            <div style={styles.codeBox}>
              <p style={styles.codeLabel}>Your Contestant ID</p>
              <p style={styles.code}>{contestant.abbreviation || contestant.contestant_code}</p>
              <p style={styles.codeLabel}>Your Voting Link</p>
              <p style={styles.link}>{contestant.vote_url}</p>
            </div>
          )}

          <p style={styles.note}>
            Share your link with friends and family to start collecting votes.
            Your entry is pending admin approval — you'll be notified once approved.
          </p>

          <div style={styles.flowers}>🎉 🎊 ✨ 🎈 🎆</div>

          <button style={styles.btn} onClick={onClose}>
            Start Sharing My Link →
          </button>
        </div>
      </div>
    </>
  )
}

const styles = {
  overlay: { position:'fixed', inset:0, background:'rgba(0,0,0,0.85)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:1000, padding:20 },
  modal:   { background:'var(--dark2)', border:'2px solid var(--gold)', borderRadius:24, padding:'40px 32px', maxWidth:500, width:'100%', textAlign:'center', animation:'popIn 0.5s cubic-bezier(.175,.885,.32,1.275)' },
  flowers: { fontSize:28, marginBottom:12, letterSpacing:6 },
  trophy:  { fontSize:72, marginBottom:8, display:'block', animation:'crownFloat 2s ease-in-out infinite' },
  title:   { fontSize:36, color:'var(--gold)', marginBottom:6 },
  name:    { fontSize:22, fontWeight:700, marginBottom:12 },
  msg:     { fontSize:15, color:'var(--muted)', lineHeight:1.7, marginBottom:20 },
  codeBox: { background:'var(--dark3)', border:'1px solid var(--border)', borderRadius:12, padding:16, marginBottom:16, textAlign:'left' },
  codeLabel:{ fontSize:11, color:'var(--muted)', textTransform:'uppercase', letterSpacing:1, marginBottom:4 },
  code:    { fontSize:24, fontWeight:800, color:'var(--gold)', marginBottom:12, fontFamily:'monospace' },
  link:    { fontSize:12, color:'var(--blue)', wordBreak:'break-all' },
  note:    { fontSize:13, color:'var(--muted)', lineHeight:1.6, marginBottom:20 },
  btn:     { padding:'14px 32px', background:'var(--gold)', color:'var(--black)', border:'none', borderRadius:10, fontWeight:700, fontSize:16, width:'100%' },
}
