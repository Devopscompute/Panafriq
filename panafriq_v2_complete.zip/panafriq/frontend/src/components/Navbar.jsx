import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'
import { Menu, X, Trophy, LogOut, LayoutDashboard, User } from 'lucide-react'

export default function Navbar() {
  const { user, logout } = useAuth()
  const nav = useNavigate()
  const [open, setOpen] = useState(false)

  const handleLogout = () => { logout(); nav('/') }

  return (
    <nav style={styles.nav}>
      <Link to="/" style={styles.logo}>
        <Trophy size={22} color="var(--gold)" />
        <span>Pan<span style={{ color: 'var(--gold)' }}>Afriq</span></span>
      </Link>

      <div style={{ ...styles.links, ...(open ? styles.linksOpen : {}) }}>
        <Link to="/" style={styles.link} onClick={() => setOpen(false)}>Home</Link>
        <Link to="/leaderboard" style={styles.link} onClick={() => setOpen(false)}>Leaderboard</Link>
        {user ? (
          <>
            {(user.is_admin || user.is_staff) && (
              <Link to="/admin" style={styles.link} onClick={() => setOpen(false)}>
                <LayoutDashboard size={14} /> Admin
              </Link>
            )}
            <Link to="/join-contest" style={styles.btnOutline} onClick={() => setOpen(false)}>Join Contest</Link>
            <button onClick={handleLogout} style={styles.btnGhost}>
              <LogOut size={14} /> Logout
            </button>
          </>
        ) : (
          <>
            <Link to="/login" style={styles.link} onClick={() => setOpen(false)}>Login</Link>
            <Link to="/register" style={styles.btnGold} onClick={() => setOpen(false)}>Register</Link>
          </>
        )}
      </div>

      <button style={styles.burger} onClick={() => setOpen(!open)}>
        {open ? <X size={22} /> : <Menu size={22} />}
      </button>
    </nav>
  )
}

const styles = {
  nav: { display:'flex', alignItems:'center', justifyContent:'space-between', padding:'0 24px', height:64, background:'rgba(10,10,10,0.95)', borderBottom:'1px solid var(--border)', position:'sticky', top:0, zIndex:100, backdropFilter:'blur(12px)' },
  logo: { display:'flex', alignItems:'center', gap:8, fontSize:22, fontFamily:"'Playfair Display',serif", fontWeight:700, color:'var(--text)' },
  links: { display:'flex', alignItems:'center', gap:8 },
  linksOpen: { position:'absolute', top:64, left:0, right:0, flexDirection:'column', background:'var(--dark)', padding:24, borderBottom:'1px solid var(--border)' },
  link: { padding:'8px 14px', color:'var(--muted)', fontSize:14, fontWeight:500, borderRadius:8, transition:'color .2s', ':hover':{ color:'var(--text)' } },
  btnGold: { padding:'8px 18px', background:'var(--gold)', color:'var(--black)', borderRadius:8, fontWeight:600, fontSize:14, border:'none' },
  btnOutline: { padding:'8px 18px', border:'1px solid var(--gold)', color:'var(--gold)', borderRadius:8, fontWeight:600, fontSize:14, background:'transparent' },
  btnGhost: { padding:'8px 14px', background:'transparent', border:'none', color:'var(--muted)', fontSize:14, display:'flex', alignItems:'center', gap:6 },
  burger: { display:'none', background:'none', border:'none', color:'var(--text)', '@media(max-width:768px)':{ display:'block' } },
}
