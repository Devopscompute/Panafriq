# PanAfriq Kids Contest Platform

Full-stack kids beauty contest platform with paid voting, multi-stage competitions, and multi-currency support.

---

## Tech Stack

| Layer    | Technology                          |
|----------|-------------------------------------|
| Backend  | Django 4.2 + Django REST Framework  |
| Database | MySQL 8+                            |
| Frontend | React 18 + Vite                     |
| Payments | Flutterwave (webhook-verified only) |
| Auth     | JWT (SimpleJWT)                     |

---

## Project Structure

```
panafriq/
├── backend/
│   ├── config/          # Django settings, URLs
│   ├── apps/
│   │   ├── users/       # Auth, voter sessions
│   │   ├── contests/    # Contests, contestants, votes
│   │   └── payments/    # Transactions, Flutterwave webhook
│   ├── manage.py
│   ├── requirements.txt
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── pages/       # All React pages
│   │   ├── components/  # Navbar, AgeGate, ContestantCard
│   │   ├── contexts/    # AuthContext
│   │   └── api/         # Axios API module
│   └── package.json
├── setup_db.sql
└── README.md
```

---

## Quick Setup

### 1. Database
```bash
mysql -u root -p < setup_db.sql
```

### 2. Backend
```bash
cd backend
cp .env.example .env
# Edit .env with your credentials

pip install -r requirements.txt
python manage.py makemigrations users contests payments
python manage.py migrate
python manage.py createsuperuser
python manage.py seed_contest       # Creates a sample contest
python manage.py runserver
```

### 3. Frontend
```bash
cd frontend
npm install
npm run dev
```

Frontend runs on http://localhost:5173
Backend runs on http://localhost:8000
Django Admin at http://localhost:8000/admin/

---

## Environment Variables (.env)

```env
SECRET_KEY=your-django-secret-key
DEBUG=True
ALLOWED_HOSTS=localhost,127.0.0.1

DB_NAME=panafriq_db
DB_USER=panafriq_user
DB_PASSWORD=StrongPass123!
DB_HOST=localhost
DB_PORT=3306

FLUTTERWAVE_SECRET_KEY=FLWSECK_TEST-xxxxxxxxxxxx
FLUTTERWAVE_PUBLIC_KEY=FLWPUBK_TEST-xxxxxxxxxxxx
FLUTTERWAVE_SECRET_HASH=your-webhook-secret-hash

EXCHANGE_RATE_API_KEY=your-key    # Free at exchangerate-api.com
FRONTEND_URL=http://localhost:5173
CORS_ORIGINS=http://localhost:5173
```

---

## Payment Flow (Webhook-Only Architecture)

```
User selects votes → clicks Pay
        ↓
Backend creates PENDING transaction
        ↓
Frontend redirects to Flutterwave hosted checkout
        ↓
User pays (card / MoMo / bank transfer)
        ↓
Flutterwave fires POST /api/payments/webhook/flutterwave/
        ↓
Backend verifies signature (verif-hash header)
        ↓
Backend re-verifies with Flutterwave GET /transactions/:id/verify
        ↓
Amount confirmed → votes credited atomically → transaction = SUCCESS
        ↓
Frontend polls GET /api/payments/verify/?reference=PAQ-xxx
        ↓
Shows success screen with vote count
```

**Votes are NEVER credited on the frontend redirect.**
Only the webhook credits votes — after double verification.

---

## Currency Support

| Country    | Currency     | Rate         |
|------------|--------------|--------------|
| Nigeria 🇳🇬 | NGN (₦)     | Base         |
| Ghana 🇬🇭   | GHS (GH₵)   | Live via API |
| Cameroon 🇨🇲 | XAF (CFA)  | Live via API |
| Other       | NGN (₦)     | Default      |

---

## Contest Stages

| Stage   | Min Votes | Duration |
|---------|-----------|----------|
| Stage 1 | 100 votes | 2 weeks  |
| Stage 2 | 400 votes | 2 weeks  |
| Finals  | Most wins | 2 weeks  |

---

## Anti-Fraud System

- IP-based rate limiting (flags 10+ transactions/hour from same IP)
- Amount verification via Flutterwave re-verify API
- Duplicate payment reference protection (idempotent webhook)
- Device fingerprint tracking on voter sessions
- All fraud flags visible in Django Admin → FraudFlag

---

## Flutterwave Webhook Setup

1. Log into your Flutterwave dashboard
2. Go to Settings → Webhooks
3. Set URL to: `https://yourdomain.com/api/payments/webhook/flutterwave/`
4. Set Secret Hash — copy it into `FLUTTERWAVE_SECRET_HASH` in .env
5. Enable event: `charge.completed`

---

## Manual Payment Flow (Bank Transfer / WhatsApp)

1. Voter selects "WhatsApp" payment method
2. System shows bank account details + reference code
3. Voter transfers money and sends screenshot to WhatsApp
4. Admin logs into dashboard → Transactions tab
5. Admin clicks "Confirm" → votes credited immediately

---

## API Endpoints

### Auth
| Method | URL | Description |
|--------|-----|-------------|
| POST | /api/auth/register/ | Register new user |
| POST | /api/auth/login/ | Login |
| POST | /api/auth/token/refresh/ | Refresh JWT |
| GET/PATCH | /api/auth/profile/ | View/update profile |
| POST | /api/auth/voter-session/ | Anonymous voter age check |

### Contests
| Method | URL | Description |
|--------|-----|-------------|
| GET | /api/contests/ | List all contests |
| GET | /api/contests/leaderboard/ | Live leaderboard |
| GET | /api/contests/contestant/:slug/ | Contestant profile |
| POST | /api/contests/register/ | Join contest |
| POST | /api/contests/admin/contestants/:id/approve/ | Approve contestant |
| POST | /api/contests/admin/contestants/:id/reject/ | Reject contestant |

### Payments
| Method | URL | Description |
|--------|-----|-------------|
| GET | /api/payments/pricing/ | Get local currency price |
| POST | /api/payments/initiate/ | Start payment |
| POST | /api/payments/webhook/flutterwave/ | Flutterwave webhook (votes credited here) |
| GET | /api/payments/verify/ | Poll payment status |
| POST | /api/payments/manual/confirm/:ref/ | Admin confirms manual payment |
| GET | /api/payments/admin/transactions/ | All transactions |

---

## Deployment (Production)

### Backend
```bash
pip install gunicorn
gunicorn config.wsgi:application --bind 0.0.0.0:8000 --workers 4
```

### Frontend
```bash
npm run build
# Serve the dist/ folder via Nginx
```

### Nginx config (sample)
```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location /api/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    location /media/ {
        alias /path/to/backend/media/;
    }

    location / {
        root /path/to/frontend/dist;
        try_files $uri $uri/ /index.html;
    }
}
```
