"""
Flutterwave integration helpers.
All vote crediting happens EXCLUSIVELY through the webhook — never client-side.
"""
import hmac, hashlib, requests
from django.conf import settings


def verify_webhook_signature(received_hash: str) -> bool:
    """Compare the received verif-hash header with our stored secret."""
    expected = settings.FLUTTERWAVE_SECRET_HASH
    if not expected:
        return False
    return hmac.compare_digest(expected, received_hash)


def verify_transaction(flw_transaction_id: str) -> dict | None:
    """
    Re-verify a transaction directly with Flutterwave's API.
    Returns the data dict on success, None on failure.
    Always call this inside the webhook before crediting votes.
    """
    if not settings.FLUTTERWAVE_SECRET_KEY or not flw_transaction_id:
        return None
    try:
        r = requests.get(
            f"https://api.flutterwave.com/v3/transactions/{flw_transaction_id}/verify",
            headers={"Authorization": f"Bearer {settings.FLUTTERWAVE_SECRET_KEY}"},
            timeout=10,
        )
        data = r.json()
        if data.get("status") == "success" and data["data"].get("status") == "successful":
            return data["data"]
    except Exception:
        pass
    return None


def create_payment_link(payload: dict) -> str | None:
    """
    Send a payment initiation request to Flutterwave and return the hosted link.
    Returns the payment URL or None on failure.
    """
    headers = {
        "Authorization": f"Bearer {settings.FLUTTERWAVE_SECRET_KEY}",
        "Content-Type": "application/json",
    }
    try:
        r = requests.post(
            "https://api.flutterwave.com/v3/payments",
            json=payload, headers=headers, timeout=15,
        )
        data = r.json()
        if data.get("status") == "success":
            return data["data"]["link"]
    except Exception:
        pass
    return None
