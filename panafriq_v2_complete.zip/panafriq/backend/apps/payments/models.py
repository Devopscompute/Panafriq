from django.db import models
from django.conf import settings
import uuid


class Transaction(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('success', 'Success'),
        ('failed', 'Failed'),
        ('manual_pending', 'Manual Pending Verification'),
        ('manual_rejected', 'Manual Rejected'),
    ]
    METHOD_CHOICES = [
        ('card', 'Card'),
        ('momo', 'MTN MoMo'),
        ('bank_transfer', 'Bank Transfer'),
        ('manual', 'Manual Bank Transfer'),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    contestant = models.ForeignKey(
        'contests.Contestant', on_delete=models.CASCADE, related_name='transactions'
    )
    voter_user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True
    )
    voter_session_token = models.CharField(max_length=255, blank=True)
    voter_email         = models.EmailField(blank=True)
    voter_name          = models.CharField(max_length=200, blank=True)  # name of voter
    vote_count          = models.PositiveIntegerField()
    amount_ngn          = models.DecimalField(max_digits=12, decimal_places=2)
    amount_paid         = models.DecimalField(max_digits=12, decimal_places=2)
    currency            = models.CharField(max_length=5, default='NGN')
    exchange_rate       = models.DecimalField(max_digits=10, decimal_places=4, default=1.0)
    payment_method      = models.CharField(max_length=20, choices=METHOD_CHOICES, default='card')
    payment_reference   = models.CharField(max_length=255, unique=True, blank=True)
    flutterwave_txn_id  = models.CharField(max_length=255, blank=True)
    status              = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    ip_address          = models.GenericIPAddressField(null=True, blank=True)

    # Manual payment proof upload
    payment_proof       = models.ImageField(upload_to='payment_proofs/', null=True, blank=True)
    proof_uploaded_at   = models.DateTimeField(null=True, blank=True)
    bank_name           = models.CharField(max_length=100, blank=True)
    bank_account_name   = models.CharField(max_length=200, blank=True)
    transfer_amount     = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)

    admin_note          = models.TextField(blank=True)
    admin_confirmed_by  = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
        null=True, blank=True, related_name='confirmed_transactions'
    )
    admin_confirmed_at  = models.DateTimeField(null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.payment_reference} — {self.vote_count} votes ({self.status})"

    class Meta:
        db_table = 'transactions'
        ordering = ['-created_at']


class FraudFlag(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    transaction = models.ForeignKey(
        Transaction, on_delete=models.CASCADE, related_name='fraud_flags'
    )
    ip_address  = models.GenericIPAddressField(blank=True, null=True)
    reason      = models.TextField()
    is_resolved = models.BooleanField(default=False)
    created_at  = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'fraud_flags'
