from django.db import models
from django.conf import settings
from django.utils import timezone
import uuid


class Contest(models.Model):
    STATUS_CHOICES = [
        ('upcoming', 'Upcoming'), ('stage_1', 'Stage 1'),
        ('stage_2', 'Stage 2'), ('stage_3', 'Final Stage'), ('ended', 'Ended'),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    banner = models.ImageField(upload_to='contests/', null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='upcoming')
    stage_1_start = models.DateTimeField()
    stage_1_end   = models.DateTimeField()
    stage_2_start = models.DateTimeField()
    stage_2_end   = models.DateTimeField()
    stage_3_start = models.DateTimeField()
    stage_3_end   = models.DateTimeField()
    stage_1_min_votes = models.IntegerField(default=100)
    stage_2_min_votes = models.IntegerField(default=600)  # Updated
    prize_description = models.TextField(blank=True)
    # Top 10 compensation
    top_10_compensation = models.TextField(
        blank=True,
        default='Top 10 contestants receive special recognition and compensation prizes.'
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'contests'
        ordering = ['-created_at']


class Contestant(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending Approval'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
        ('eliminated', 'Eliminated'),
        ('winner', 'Winner'),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE, related_name='contestant_entries'
    )
    contest = models.ForeignKey(
        Contest, on_delete=models.CASCADE, related_name='contestants'
    )
    contestant_code = models.CharField(max_length=20, unique=True)
    # Abbreviation e.g. "PAQ-0001"
    abbreviation = models.CharField(max_length=20, blank=True)
    slug = models.SlugField(max_length=100, unique=True)
    bio = models.TextField(blank=True)
    photo = models.ImageField(upload_to='contestants/')
    total_votes   = models.PositiveIntegerField(default=0)
    stage_1_votes = models.PositiveIntegerField(default=0)
    stage_2_votes = models.PositiveIntegerField(default=0)
    stage_3_votes = models.PositiveIntegerField(default=0)
    current_stage = models.IntegerField(default=1)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    vote_link = models.CharField(max_length=255, blank=True)
    rank = models.PositiveIntegerField(default=0)
    is_winner = models.BooleanField(default=False)
    is_top_10 = models.BooleanField(default=False)
    eliminated_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def get_vote_url(self):
        return f"{settings.FRONTEND_URL}/vote/{self.slug}"

    def get_profile_url(self):
        return f"{settings.FRONTEND_URL}/contestant/{self.slug}"

    def save(self, *args, **kwargs):
        if not self.slug:
            base = f"{self.user.first_name}-{self.user.last_name}".lower().replace(' ', '-')
            self.slug = f"{base}-{str(self.id)[:8]}"
        if not self.vote_link:
            self.vote_link = self.get_vote_url()
        if not self.abbreviation and self.contestant_code:
            self.abbreviation = f"PAQ-{self.contestant_code.replace('CK', '')}"
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.user.get_full_name()} [{self.abbreviation}]"

    class Meta:
        db_table = 'contestants'
        ordering = ['-total_votes']


class Vote(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    contestant = models.ForeignKey(Contestant, on_delete=models.CASCADE, related_name='votes')
    voter_user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True
    )
    vote_count = models.PositiveIntegerField()
    stage = models.IntegerField(default=1)
    ip_address = models.GenericIPAddressField()
    payment_reference = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    is_flagged = models.BooleanField(default=False)

    class Meta:
        db_table = 'votes'
        ordering = ['-created_at']
