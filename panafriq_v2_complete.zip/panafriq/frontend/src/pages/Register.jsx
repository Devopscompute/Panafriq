import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { register, googleSSO } from '../api'
import { useAuth } from '../contexts/AuthContext'
import CongratulationsModal from '../components/CongratulationsModal'
import toast from 'react-hot-toast'

export default function Register() {
  const nav = useNavigate()
  const { loginUser } = useAuth()
  const [form, setForm] = useState({
    first_name:'', last_name:'', email:'', phone:'', password:'',
    confirm_password:'', country:'NG', date_of_birth:'', whatsapp_number:''
  })
  const [photo, setPhoto] = useState(null)
  const [preview, setPreview] = useState(null)
  const [loading, setLoading] = useState(false)
  const [showCongrats, setShowCongrats] = useState(false)
  const [regUser, setRegUser] = useState(null)

  const set = k => e => setForm({ ...form, [k]: e.target.value })

  const handlePhoto = e => {
    const f = e.target.files[0]
    if (!f) return
    if (f.size > 5 * 1024 * 1024) { toast.error('Photo must be under 5MB'); return }
    setPhoto(f)
    setPreview(URL.createObjectURL(f))
  }

  const handleSubmit = async e => {
    e.preventDefault()
    if (!photo) { toast.error('Please upload your profile photo'); return }
    setLoading(true)
    try {
      const fd = new FormData()
      Object.entries(form).forEach(([k, v]) => fd.append(k, v))
      fd.append('profile_picture', photo)
      const { data } = await register(fd)
      loginUser(data.user, data.access, data.refresh)
      setRegUser(data.user)
      setShowCongrats(true)
    } catch (err) {
      const d = err.response?.data
      const msg = typeof d === 'object' ? Object.values(d).flat().join(' ') : 'Registration failed'
      toast.error(msg)
    } finally { setLoading(false) }
  }

  if (showCongrats) return (
    <CongratulationsModal
      user={regUser}
      onClose={() => { setShowCongrats(false); nav('/join-contest') }}
    />
  )

  return (
    <div style={s.page}>
      <div style={s.card}>
        <h2 style={s.title}>Create Your Account</h2>
        <p style={s.sub}>Join PanAfriq — Africa's Premier Contest. Must be 16 or older.</p>

        {/* Google SSO */}
        <div style={s.ssoRow}>
          <button style={s.googleBtn} onClick={async () => {
            toast('Google SSO — connect your Google Client ID in .env', { icon: 'ℹ️' })
          }}>
            <img src="https://www.google.com/favicon.ico" width={16} height={16} alt="G"/>
            Continue with Google
          </button>
          <button style={s.fbBtn} onClick={() => {
            toast('Facebook SSO — connect your Facebook App ID in .env', { icon: 'ℹ️' })
          }}>
            <span style={{ fontWeight:800, color:'#1877F2' }}>f</span>
            Continue with Facebook
          </button>
        </div>
        <div style={s.divider}><span>or register with email</span></div>

        <form onSubmit={handleSubmit} style={s.form}>
          {/* Profile photo — required */}
          <div style={s.field}>
            <label style={s.label}>Profile Photo <span style={{ color:'var(--red)' }}>*</span></label>
            <div style={s.photoWrap} onClick={() => document.getElementById('regPhoto').click()}>
              {preview
                ? <img src={preview} style={s.photoPreview} alt="preview"/>
                : <div style={s.photoPlaceholder}><span style={{fontSize:36}}>📷</span><span style={{fontSize:13,color:'var(--muted)'}}>Upload your best photo</span></div>
              }
            </div>
            <input id="regPhoto" type="file" accept="image/*" onChange={handlePhoto} style={{display:'none'}}/>
            <p style={s.hint}>This photo appears on your contestant profile and voting link page.</p>
          </div>

          <div style={s.row}>
            <Field label="First Name" value={form.first_name} onChange={set('first_name')} required/>
            <Field label="Last Name"  value={form.last_name}  onChange={set('last_name')}  required/>
          </div>
          <Field label="Email" type="email" value={form.email} onChange={set('email')} required/>
          <Field label="Phone" type="tel" value={form.phone} onChange={set('phone')} placeholder="+234..."/>
          <Field label="WhatsApp Number" type="tel" value={form.whatsapp_number} onChange={set('whatsapp_number')} placeholder="+234..."/>
          <div style={s.field}>
            <label style={s.label}>Country</label>
            <select style={s.input} value={form.country} onChange={set('country')}>
              <option value="NG">🇳🇬 Nigeria</option>
              <option value="GH">🇬🇭 Ghana</option>
              <option value="CM">🇨🇲 Cameroon</option>
              <option value="OTHER">🌍 Other</option>
            </select>
          </div>
          <div style={s.field}>
            <label style={s.label}>Date of Birth <span style={{color:'var(--red)'}}>*</span> <span style={{color:'var(--muted)',fontSize:12}}>(Must be 16+)</span></label>
            <input type="date" required style={s.input} value={form.date_of_birth} onChange={set('date_of_birth')}/>
          </div>
          <Field label="Password (min 8 chars)" type="password" value={form.password} onChange={set('password')} required/>
          <Field label="Confirm Password" type="password" value={form.confirm_password} onChange={set('confirm_password')} required/>

          <div style={s.infoBox}>
            ✅ After registering, a 6-digit OTP will be sent to your email to verify your account.
          </div>

          <button type="submit" disabled={loading} style={s.btn}>
            {loading ? 'Creating Account...' : 'Create Account & Get My Link'}
          </button>
        </form>
        <p style={s.foot}>Already have an account? <Link to="/login" style={{color:'var(--gold)'}}>Login</Link></p>
      </div>
    </div>
  )
}

function Field({ label, ...props }) {
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
      <label style={{ fontSize:13, color:'var(--muted)', fontWeight:500 }}>{label}</label>
      <input style={{ padding:'12px 14px', background:'var(--dark3)', border:'1px solid var(--border)', borderRadius:8, color:'var(--text)', fontSize:14, outline:'none' }} {...props}/>
    </div>
  )
}

const s = {
  page: { minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', padding:24 },
  card: { background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:20, padding:40, width:'100%', maxWidth:540 },
  title: { fontSize:28, color:'var(--gold)', marginBottom:6 },
  sub: { color:'var(--muted)', fontSize:13, marginBottom:20 },
  ssoRow: { display:'flex', gap:10, marginBottom:16 },
  googleBtn: { flex:1, padding:'11px', background:'white', border:'none', borderRadius:8, fontWeight:600, fontSize:13, display:'flex', alignItems:'center', justifyContent:'center', gap:8, cursor:'pointer', color:'#333' },
  fbBtn: { flex:1, padding:'11px', background:'#E7F0FD', border:'none', borderRadius:8, fontWeight:600, fontSize:13, display:'flex', alignItems:'center', justifyContent:'center', gap:8, cursor:'pointer', color:'#333' },
  divider: { textAlign:'center', color:'var(--muted)', fontSize:12, margin:'12px 0', position:'relative' },
  form: { display:'flex', flexDirection:'column', gap:14 },
  row: { display:'grid', gridTemplateColumns:'1fr 1fr', gap:14 },
  field: { display:'flex', flexDirection:'column', gap:6 },
  label: { fontSize:13, color:'var(--muted)', fontWeight:500 },
  input: { padding:'12px 14px', background:'var(--dark3)', border:'1px solid var(--border)', borderRadius:8, color:'var(--text)', fontSize:14, outline:'none' },
  photoWrap: { background:'var(--dark3)', border:'2px dashed var(--border)', borderRadius:12, height:160, cursor:'pointer', overflow:'hidden', display:'flex', alignItems:'center', justifyContent:'center' },
  photoPreview: { width:'100%', height:'100%', objectFit:'cover' },
  photoPlaceholder: { display:'flex', flexDirection:'column', alignItems:'center', gap:8 },
  hint: { fontSize:11, color:'var(--muted)' },
  infoBox: { background:'rgba(46,204,113,0.08)', border:'1px solid rgba(46,204,113,0.2)', borderRadius:8, padding:12, fontSize:12, color:'#2ECC71', lineHeight:1.6 },
  btn: { padding:'14px', background:'var(--gold)', color:'var(--black)', border:'none', borderRadius:10, fontWeight:700, fontSize:15 },
  foot: { textAlign:'center', marginTop:16, color:'var(--muted)', fontSize:14 },
}
