from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from apps.security.views import honeypot_view

urlpatterns = [
    # Real admin behind secret path
    path(f'{settings.REAL_ADMIN_PATH}/', admin.site.urls),
    # Honeypot — logs attackers
    path(f'{settings.ADMIN_HONEYPOT_PATH}/', honeypot_view),
    path('admin/', honeypot_view),  # also trap /admin/
    # APIs
    path('api/auth/',          include('apps.users.urls')),
    path('api/contests/',      include('apps.contests.urls')),
    path('api/payments/',      include('apps.payments.urls')),
    path('api/notifications/', include('apps.notifications.urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
