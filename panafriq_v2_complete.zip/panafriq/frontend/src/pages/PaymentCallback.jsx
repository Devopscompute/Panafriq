import React, { useEffect, useState } from 'react'
import { useSearchParams, useLocation, Link } from 'react-router-dom'
import { verifyPayment } from '../api'
import { CheckCircle, XCircle, Clock, Copy } from 'lucide-react'
import toast from 'react-hot-toast'

export default function PaymentCallback() {
  const [params] = useSearchParams()
  const location = useLocation()
  const [status, setStatus] = useState('loading')
  const [txn, setTxn] = useState(null)
  const [manualData, setManualData] = useState(null)

  useEffect(() => {
    // Manual payment flow
    if (params.get('method') === 'manual') {
      setManualData(location.state?.manualData)
      setStatus('manual')
      return
    }

    // Flutterwave redirect — verify via our backend (which trusts webhook)
    const ref = params.get('tx_ref') || params.get('reference')
    const flwStatus = params.get('status')

    if (!ref) { setStatus('error'); return }

    // Poll verify endpoint (webhook may fire before or after redirect)
    let attempts = 0
    const poll = async () => {
      try {
        const { data } = await verifyPayment(ref)
        setTxn(data)
        if (data.status === 'success') {
          setStatus('success')
        } else if (attempts < 5) {
          attempts++
          setTimeout(poll, 2000)
        } else {
          setStatus(flwStatus === 'successful' ? 'pending' : 'failed')
        }
      } catch { setStatus('error') }
    }
    poll()
  }, [])

  if (status === 'loading') return (
    <div style={styles.page}>
      <div style={styles.card}>
        <div style={styles.spinner} />
        <h2 style={styles.title}>Verifying Payment...</h2>
        <p style={styles.sub}>Please wait while we confirm your payment via Flutterwave</p>
      </div>
    </div>
  )

  if (status === 'manual') return (
    <div style={styles.page}>
      <div style={styles.card}>
        <div style={styles.icon}>📋</div>
        <h2 style={{ ...styles.title, color:'var(--gold)' }}>Manual Payment Instructions</h2>
        <p style={styles.sub}>Transfer the amount below and send proof to WhatsApp</p>
        {manualData && (
          <div style={styles.manualBox}>
            <Row k="Reference" v={manualData.reference} copyable />
            <Row k="Amount" v={`₦${manualData.amount_ngn?.toLocaleString()}`} />
            {manualData.local_amount !== manualData.amount_ngn && (
              <Row k={`${manualData.currency} Amount`} v={`${manualData.currency} ${manualData.local_amount?.toLocaleString()}`} />
            )}
            <div style={styles.divider} />
            <Row k="Bank" v={manualData.bank_details?.bank} />
            <Row k="Account Name" v={manualData.bank_details?.account_name} />
            <Row k="Account Number" v={manualData.bank_details?.account_number} copyable />
          </div>
        )}
        <a href={`https://wa.me/${manualData?.whatsapp?.replace(/\D/g,'')}`} target="_blank"
           style={styles.whatsappBtn}>📱 Send Proof on WhatsApp</a>
        <p style={styles.note}>Votes will be credited within 30 minutes of confirmation.</p>
      </div>
    </div>
  )

  if (status === 'success') return (
    <div style={styles.page}>
      <div style={styles.card}>
        <CheckCircle size={64} color="var(--green)" style={{ marginBottom:16 }} />
        <h2 style={{ ...styles.title, color:'var(--green)' }}>Payment Successful!</h2>
        <p style={styles.sub}>Your votes have been credited automatically.</p>
        {txn && (
          <div style={styles.infoBox}>
            <Row k="Votes Added" v={txn.vote_count?.toLocaleString()} />
            <Row k="Contestant" v={txn.contestant} />
          </div>
        )}
        <Link to={`/contestant/${txn?.contestant}`} style={styles.btn}>View Profile</Link>
        <Link to="/leaderboard" style={styles.btnSecondary}>See Leaderboard</Link>
      </div>
    </div>
  )

  if (status === 'pending') return (
    <div style={styles.page}>
      <div style={styles.card}>
        <Clock size={64} color="var(--gold)" style={{ marginBottom:16 }} />
        <h2 style={{ ...styles.title, color:'var(--gold)' }}>Payment Processing</h2>
        <p style={styles.sub}>Your payment is being confirmed. Votes will be credited automatically once the webhook confirms. This usually takes under 60 seconds.</p>
        <Link to="/" style={styles.btn}>Go Home</Link>
      </div>
    </div>
  )

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <XCircle size={64} color="var(--red)" style={{ marginBottom:16 }} />
        <h2 style={{ ...styles.title, color:'var(--red)' }}>Payment Failed</h2>
        <p style={styles.sub}>Something went wrong. No charge was made. Please try again.</p>
        <button onClick={() => window.history.back()} style={styles.btn}>Try Again</button>
      </div>
    </div>
  )
}

function Row({ k, v, copyable }) {
  const copy = () => { navigator.clipboard.writeText(v); toast.success('Copied!') }
  return (
    <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'10px 0', borderBottom:'1px solid var(--border)' }}>
      <span style={{ fontSize:13, color:'var(--muted)' }}>{k}</span>
      <div style={{ display:'flex', alignItems:'center', gap:8 }}>
        <span style={{ fontWeight:600, fontSize:14 }}>{v}</span>
        {copyable && <button onClick={copy} style={{ background:'none', border:'none', cursor:'pointer', color:'var(--gold)' }}><Copy size={14} /></button>}
      </div>
    </div>
  )
}

const styles = {
  page: { minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', padding:24 },
  card: { background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:20, padding:40, maxWidth:500, width:'100%', textAlign:'center', display:'flex', flexDirection:'column', alignItems:'center', gap:12 },
  spinner: { width:56, height:56, border:'4px solid var(--border)', borderTop:'4px solid var(--gold)', borderRadius:'50%', animation:'spin 1s linear infinite', marginBottom:8 },
  icon: { fontSize:56 },
  title: { fontSize:26 },
  sub: { color:'var(--muted)', fontSize:14, lineHeight:1.6, maxWidth:380 },
  manualBox: { width:'100%', background:'var(--dark3)', border:'1px solid var(--border)', borderRadius:12, padding:20, textAlign:'left' },
  divider: { height:1, background:'var(--border)', margin:'8px 0' },
  infoBox: { width:'100%', background:'var(--dark3)', borderRadius:12, padding:20, textAlign:'left' },
  btn: { padding:'13px 28px', background:'var(--gold)', color:'var(--black)', borderRadius:10, fontWeight:700, fontSize:15, width:'100%', textAlign:'center' },
  btnSecondary: { padding:'13px 28px', border:'1px solid var(--border)', color:'var(--muted)', borderRadius:10, fontSize:14, width:'100%', textAlign:'center' },
  whatsappBtn: { padding:'13px 24px', background:'#25D366', color:'white', borderRadius:10, fontWeight:700, fontSize:15, width:'100%', textAlign:'center' },
  note: { fontSize:12, color:'var(--muted)' },
}
