import React from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { AuthProvider, useAuth } from './contexts/AuthContext'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import Landing from './pages/Landing'
import Register from './pages/Register'
import Login from './pages/Login'
import VerifyOTP from './pages/VerifyOTP'
import ContestantProfile from './pages/ContestantProfile'
import VotePage from './pages/VotePage'
import Leaderboard from './pages/Leaderboard'
import JoinContest from './pages/JoinContest'
import PaymentCallback from './pages/PaymentCallback'
import AdminDashboard from './pages/AdminDashboard'
import AgeGate from './components/AgeGate'
import NotFound from './pages/NotFound'

function AdminRoute({ children }) {
  const { user, loading } = useAuth()
  if (loading) return null
  return (user?.is_admin || user?.is_staff) ? children : <Navigate to="/" replace/>
}

function PrivateRoute({ children }) {
  const { user, loading } = useAuth()
  if (loading) return null
  return user ? children : <Navigate to="/login" replace/>
}

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Toaster position="top-right" toastOptions={{
          style: { background:'#1A1D26', color:'#F0EDE4', border:'1px solid rgba(201,168,76,0.3)', borderRadius:'10px' }
        }}/>
        <Navbar/>
        <main>
          <Routes>
            <Route path="/"                 element={<Landing/>}/>
            <Route path="/register"         element={<Register/>}/>
            <Route path="/login"            element={<Login/>}/>
            <Route path="/verify-otp"       element={<PrivateRoute><VerifyOTP/></PrivateRoute>}/>
            <Route path="/join-contest"     element={<PrivateRoute><JoinContest/></PrivateRoute>}/>
            <Route path="/leaderboard"      element={<Leaderboard/>}/>
            <Route path="/contestant/:slug" element={<ContestantProfile/>}/>
            <Route path="/vote/:slug"       element={<AgeGate><VotePage/></AgeGate>}/>
            <Route path="/payment/callback" element={<PaymentCallback/>}/>
            <Route path="/admin"            element={<AdminRoute><AdminDashboard/></AdminRoute>}/>
            <Route path="*"                 element={<NotFound/>}/>
          </Routes>
        </main>
        <Footer/>
      </BrowserRouter>
    </AuthProvider>
  )
}
