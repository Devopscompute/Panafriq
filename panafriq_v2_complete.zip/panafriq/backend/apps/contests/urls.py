from django.urls import path
from .views import (ContestListView, ContestDetailView, ContestantRegisterView,
                    ContestantDetailView, LeaderboardView, AdminContestantListView,
                    ApproveContestantView, RejectContestantView)

urlpatterns = [
    path('', ContestListView.as_view()),
    path('<uuid:pk>/', ContestDetailView.as_view()),
    path('register/', ContestantRegisterView.as_view()),
    path('contestant/<slug:slug>/', ContestantDetailView.as_view()),
    path('leaderboard/', LeaderboardView.as_view()),
    path('admin/contestants/', AdminContestantListView.as_view()),
    path('admin/contestants/<uuid:pk>/approve/', ApproveContestantView.as_view()),
    path('admin/contestants/<uuid:pk>/reject/', RejectContestantView.as_view()),
]
