from django.urls import path
from .views import (
    GetPricingView, InitiatePaymentView, FlutterwaveWebhookView,
    VerifyPaymentView, UploadPaymentProofView,
    ManualPaymentConfirmView, ManualPaymentRejectView,
    AdminTransactionListView,
)

urlpatterns = [
    path('pricing/',                  GetPricingView.as_view()),
    path('initiate/',                 InitiatePaymentView.as_view()),
    path('webhook/flutterwave/',      FlutterwaveWebhookView.as_view()),
    path('verify/',                   VerifyPaymentView.as_view()),
    path('proof/<str:ref>/',          UploadPaymentProofView.as_view()),
    path('manual/confirm/<str:ref>/', ManualPaymentConfirmView.as_view()),
    path('manual/reject/<str:ref>/',  ManualPaymentRejectView.as_view()),
    path('admin/transactions/',       AdminTransactionListView.as_view()),
]
