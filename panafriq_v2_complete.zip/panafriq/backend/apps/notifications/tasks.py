from celery import shared_task
from django.core.mail import send_mass_mail
from django.conf import settings
import logging

logger = logging.getLogger(__name__)


@shared_task
def send_newsletter_task(subject, body, admin_email):
    from .models import NewsletterSubscriber, NewsletterMessage
    from apps.users.models import User
    subscribers = NewsletterSubscriber.objects.filter(is_active=True).values_list('email', flat=True)
    if not subscribers:
        return 'No subscribers.'
    messages = [
        (subject, body, settings.DEFAULT_FROM_EMAIL, [email])
        for email in subscribers
    ]
    try:
        send_mass_mail(messages, fail_silently=False)
        admin = User.objects.filter(email=admin_email).first()
        NewsletterMessage.objects.create(
            subject=subject, body=body,
            sent_by=admin, recipient_count=len(messages)
        )
        return f'Newsletter sent to {len(messages)} subscribers.'
    except Exception as e:
        logger.error(f"Newsletter failed: {e}")
        return f'Failed: {e}'
