from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .models import User, VoterSession

@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ['email', 'first_name', 'last_name', 'country', 'is_verified', 'created_at']
    list_filter = ['country', 'is_verified', 'is_admin']
    search_fields = ['email', 'first_name', 'last_name']
    fieldsets = BaseUserAdmin.fieldsets + (
        ('Extra', {'fields': ('phone', 'country', 'date_of_birth', 'is_verified', 'is_admin', 'whatsapp_number')}),
    )

@admin.register(VoterSession)
class VoterSessionAdmin(admin.ModelAdmin):
    list_display = ['session_token', 'ip_address', 'country', 'age_verified', 'created_at']
