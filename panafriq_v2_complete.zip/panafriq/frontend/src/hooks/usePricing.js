import { useState, useEffect } from 'react'
import { getPricing } from '../api'

export default function usePricing(country, voteCount) {
  const [pricing, setPricing] = useState(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!voteCount || voteCount < 1) return
    setLoading(true)
    const timer = setTimeout(() => {
      getPricing(country, voteCount)
        .then(r => setPricing(r.data))
        .catch(() => {})
        .finally(() => setLoading(false))
    }, 400)
    return () => clearTimeout(timer)
  }, [country, voteCount])

  return { pricing, loading }
}
