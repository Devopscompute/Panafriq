import React from 'react'
import { Link } from 'react-router-dom'
export default function NotFound() {
  return (
    <div style={{ minHeight:'80vh', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:16, textAlign:'center', padding:24 }}>
      <div style={{ fontSize:80 }}>🏆</div>
      <h1 style={{ fontSize:48, color:'var(--gold)' }}>404</h1>
      <p style={{ color:'var(--muted)', fontSize:16 }}>This page doesn't exist.</p>
      <Link to="/" style={{ padding:'12px 24px', background:'var(--gold)', color:'var(--black)', borderRadius:10, fontWeight:700 }}>Go Home</Link>
    </div>
  )
}
