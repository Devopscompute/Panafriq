import logging, requests
from rest_framework import generics, status
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework_simplejwt.tokens import RefreshToken
from django.conf import settings
from django.core.mail import send_mail
from django.utils import timezone
from django.contrib.auth import authenticate
from datetime import date
import secrets, qrcode, io, base64

from .models import User, VoterSession
from .serializers import RegisterSerializer, LoginSerializer, UserSerializer

logger = logging.getLogger('security')


def _get_tokens(user):
    refresh = RefreshToken.for_user(user)
    return str(refresh.access_token), str(refresh)


def _send_otp_email(user):
    otp = user.generate_otp()
    send_mail(
        subject='PanAfriq — Verify Your Account',
        message=(
            f"Hello {user.first_name},\n\n"
            f"Your verification code is: {otp}\n\n"
            f"This code expires in {settings.OTP_EXPIRY_MINUTES} minutes.\n\n"
            f"If you did not register, ignore this email.\n\n"
            f"— PanAfriq Team"
        ),
        from_email=settings.DEFAULT_FROM_EMAIL,
        recipient_list=[user.email],
        fail_silently=False,
    )


class RegisterView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = RegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.save()

        ip = (request.META.get('HTTP_X_FORWARDED_FOR', '')
              or request.META.get('REMOTE_ADDR', '')).split(',')[0].strip()
        if ip:
            user.ip_address = ip
            user.save(update_fields=['ip_address'])

        # Send OTP verification email
        try:
            _send_otp_email(user)
        except Exception as e:
            logger.error(f"OTP email failed for {user.email}: {e}")

        access, refresh = _get_tokens(user)
        return Response({
            'user': UserSerializer(user).data,
            'access': access,
            'refresh': refresh,
            'message': f'Welcome {user.first_name}! Please verify your email. A 6-digit code was sent to {user.email}.',
            'requires_verification': True,
        }, status=status.HTTP_201_CREATED)


class LoginView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        access, refresh = _get_tokens(user)
        return Response({
            'user': UserSerializer(user).data,
            'access': access,
            'refresh': refresh,
            'email_verified': user.email_verified,
        })


class VerifyOTPView(APIView):
    """Verify 6-digit OTP sent to email after registration."""
    permission_classes = [IsAuthenticated]

    def post(self, request):
        code = request.data.get('otp', '').strip()
        if not code:
            return Response({'error': 'OTP code is required.'}, status=400)
        if request.user.verify_otp(code):
            return Response({'message': 'Email verified successfully! Your account is now active.'})
        return Response({'error': 'Invalid or expired OTP. Request a new one.'}, status=400)


class ResendOTPView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user
        if user.email_verified:
            return Response({'error': 'Email already verified.'}, status=400)
        try:
            _send_otp_email(user)
            return Response({'message': f'New OTP sent to {user.email}'})
        except Exception as e:
            return Response({'error': 'Could not send OTP. Try again later.'}, status=500)


class SetupTOTPView(APIView):
    """Return QR code for Google Authenticator setup."""
    permission_classes = [IsAuthenticated]

    def get(self, request):
        uri = request.user.get_totp_uri()
        # Generate QR code as base64 image
        img = qrcode.make(uri)
        buf = io.BytesIO()
        img.save(buf, format='PNG')
        qr_b64 = base64.b64encode(buf.getvalue()).decode()
        return Response({
            'qr_code': f'data:image/png;base64,{qr_b64}',
            'secret': request.user.totp_secret,
            'uri': uri,
        })

    def post(self, request):
        """Confirm TOTP setup with first code."""
        code = request.data.get('code', '')
        if request.user.verify_totp(code):
            request.user.totp_enabled = True
            request.user.save(update_fields=['totp_enabled'])
            return Response({'message': 'Two-factor authentication enabled!'})
        return Response({'error': 'Invalid TOTP code.'}, status=400)


class GoogleSSOView(APIView):
    """Exchange Google OAuth token for JWT."""
    permission_classes = [AllowAny]

    def post(self, request):
        token = request.data.get('token')
        if not token:
            return Response({'error': 'Google token required.'}, status=400)
        try:
            r = requests.get(
                f'https://www.googleapis.com/oauth2/v3/userinfo',
                headers={'Authorization': f'Bearer {token}'}, timeout=10
            )
            if r.status_code != 200:
                return Response({'error': 'Invalid Google token.'}, status=400)
            info = r.json()
            email = info.get('email')
            if not email:
                return Response({'error': 'No email from Google.'}, status=400)

            user, created = User.objects.get_or_create(
                email=email,
                defaults={
                    'username': email.split('@')[0],
                    'first_name': info.get('given_name', ''),
                    'last_name': info.get('family_name', ''),
                    'auth_provider': 'google',
                    'sso_uid': info.get('sub', ''),
                    'email_verified': True,
                    'is_verified': True,
                }
            )
            if created and info.get('picture'):
                user.set_unusable_password()
                user.save()

            access, refresh = _get_tokens(user)
            return Response({
                'user': UserSerializer(user).data,
                'access': access, 'refresh': refresh,
                'created': created,
            })
        except Exception as e:
            logger.error(f"Google SSO error: {e}")
            return Response({'error': 'Google authentication failed.'}, status=500)


class FacebookSSOView(APIView):
    """Exchange Facebook token for JWT."""
    permission_classes = [AllowAny]

    def post(self, request):
        token = request.data.get('token')
        if not token:
            return Response({'error': 'Facebook token required.'}, status=400)
        try:
            r = requests.get(
                'https://graph.facebook.com/me',
                params={'fields': 'id,name,email,first_name,last_name',
                        'access_token': token},
                timeout=10
            )
            if r.status_code != 200:
                return Response({'error': 'Invalid Facebook token.'}, status=400)
            info = r.json()
            email = info.get('email')
            if not email:
                return Response({'error': 'Facebook account has no email. Please use email registration.'}, status=400)

            user, created = User.objects.get_or_create(
                email=email,
                defaults={
                    'username': email.split('@')[0],
                    'first_name': info.get('first_name', ''),
                    'last_name': info.get('last_name', ''),
                    'auth_provider': 'facebook',
                    'sso_uid': info.get('id', ''),
                    'email_verified': True,
                    'is_verified': True,
                }
            )
            if created:
                user.set_unusable_password()
                user.save()

            access, refresh = _get_tokens(user)
            return Response({
                'user': UserSerializer(user).data,
                'access': access, 'refresh': refresh,
                'created': created,
            })
        except Exception as e:
            logger.error(f"Facebook SSO error: {e}")
            return Response({'error': 'Facebook authentication failed.'}, status=500)


class ProfileView(generics.RetrieveUpdateAPIView):
    permission_classes = [IsAuthenticated]
    serializer_class = UserSerializer

    def get_object(self):
        return self.request.user

    def update(self, request, *args, **kwargs):
        kwargs['partial'] = True
        return super().update(request, *args, **kwargs)


class CreateVoterSessionView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        dob_str = request.data.get('date_of_birth')
        if not dob_str:
            return Response({'error': 'Date of birth is required.'}, status=400)
        try:
            dob = date.fromisoformat(dob_str)
            age = (date.today() - dob).days // 365
            if age < 16:
                return Response({'error': 'You must be 16 or older to vote.'}, status=400)
        except ValueError:
            return Response({'error': 'Invalid date format.'}, status=400)

        ip = (request.META.get('HTTP_X_FORWARDED_FOR', '')
              or request.META.get('REMOTE_ADDR', '127.0.0.1')).split(',')[0].strip()
        token = secrets.token_urlsafe(32)
        VoterSession.objects.create(
            session_token=token, ip_address=ip,
            device_fingerprint=request.data.get('fingerprint', ''),
            user_agent=request.META.get('HTTP_USER_AGENT', ''),
            country=request.data.get('country', ''),
            email=request.data.get('email', ''),
            date_of_birth=dob, age_verified=True,
        )
        return Response({'session_token': token, 'age_verified': True})
