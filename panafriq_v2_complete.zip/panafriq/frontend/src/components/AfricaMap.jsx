import React from 'react'

export default function AfricaMap({ style = {} }) {
  return (
    <svg viewBox="0 0 400 500" xmlns="http://www.w3.org/2000/svg" style={{ ...style }}>
      <defs>
        <radialGradient id="glow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="#C9A84C" stopOpacity="0.3"/>
          <stop offset="100%" stopColor="#C9A84C" stopOpacity="0"/>
        </radialGradient>
        <linearGradient id="mapGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#1A1D26"/>
          <stop offset="100%" stopColor="#22263A"/>
        </linearGradient>
        <filter id="glow-filter">
          <feGaussianBlur stdDeviation="3" result="blur"/>
          <feComposite in="SourceGraphic" in2="blur" operator="over"/>
        </filter>
      </defs>
      {/* Africa outline - simplified path */}
      <path
        d="M190,20 L220,18 L250,25 L270,35 L280,55 L290,75 L295,95 L300,115
           L305,130 L310,145 L315,160 L320,175 L325,195 L330,215 L332,235
           L335,255 L338,275 L340,295 L338,315 L332,330 L322,348 L310,362
           L295,375 L278,385 L260,392 L240,396 L220,398 L200,396 L180,390
           L162,380 L148,368 L136,354 L125,338 L118,322 L112,305 L108,288
           L105,270 L103,252 L100,232 L96,212 L90,192 L85,172 L78,152
           L72,132 L68,112 L65,92 L65,72 L68,55 L75,40 L88,30 L105,22
           L125,18 L150,17 L170,18 Z"
        fill="url(#mapGrad)"
        stroke="#C9A84C"
        strokeWidth="2"
        strokeOpacity="0.8"
        filter="url(#glow-filter)"
      />
      {/* Nigeria marker */}
      <circle cx="185" cy="265" r="7" fill="#C9A84C" opacity="0.9">
        <animate attributeName="r" values="6;10;6" dur="2s" repeatCount="indefinite"/>
        <animate attributeName="opacity" values="0.9;0.5;0.9" dur="2s" repeatCount="indefinite"/>
      </circle>
      <text x="197" y="269" fill="#C9A84C" fontSize="11" fontFamily="sans-serif" fontWeight="bold">🇳🇬 NG</text>
      {/* Ghana marker */}
      <circle cx="155" cy="272" r="6" fill="#F0D080" opacity="0.9">
        <animate attributeName="r" values="5;9;5" dur="2.3s" repeatCount="indefinite"/>
      </circle>
      <text x="120" y="276" fill="#F0D080" fontSize="11" fontFamily="sans-serif">GH 🇬🇭</text>
      {/* Cameroon marker */}
      <circle cx="215" cy="278" r="6" fill="#8B6914" opacity="0.9">
        <animate attributeName="r" values="5;9;5" dur="1.8s" repeatCount="indefinite"/>
      </circle>
      <text x="225" y="282" fill="#8B6914" fontSize="11" fontFamily="sans-serif">CM 🇨🇲</text>
      {/* Glow overlay */}
      <ellipse cx="200" cy="250" rx="120" ry="150" fill="url(#glow)" opacity="0.5"/>
      {/* Stars */}
      {[{x:80,y:80},{x:320,y:120},{x:100,y:350},{x:310,y:380},{x:200,y:50}].map((s,i) => (
        <text key={i} x={s.x} y={s.y} fontSize="10" fill="#C9A84C" opacity="0.6">★</text>
      ))}
    </svg>
  )
}
