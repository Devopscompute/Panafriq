from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from .models import NewsletterSubscriber
from .tasks import send_newsletter_task


class SubscribeView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        email = request.data.get('email', '').strip().lower()
        if not email:
            return Response({'error': 'Email required.'}, status=400)
        sub, created = NewsletterSubscriber.objects.get_or_create(
            email=email,
            defaults={'user': request.user if request.user.is_authenticated else None}
        )
        if not created and not sub.is_active:
            sub.is_active = True
            sub.save(update_fields=['is_active'])
        return Response({'message': 'Subscribed to PanAfriq newsletter!'})


class UnsubscribeView(APIView):
    permission_classes = [AllowAny]

    def post(self, request):
        email = request.data.get('email', '').strip().lower()
        NewsletterSubscriber.objects.filter(email=email).update(is_active=False)
        return Response({'message': 'Unsubscribed successfully.'})


class SendNewsletterView(APIView):
    """Admin only — send newsletter to all subscribers."""
    permission_classes = [IsAuthenticated]

    def post(self, request):
        if not (request.user.is_admin or request.user.is_staff):
            return Response({'error': 'Admin access required.'}, status=403)
        subject = request.data.get('subject', '').strip()
        body    = request.data.get('body', '').strip()
        if not subject or not body:
            return Response({'error': 'Subject and body required.'}, status=400)
        send_newsletter_task.delay(subject, body, request.user.email)
        count = NewsletterSubscriber.objects.filter(is_active=True).count()
        return Response({'message': f'Newsletter queued for {count} subscribers.'})
