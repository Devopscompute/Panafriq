from rest_framework import generics, status, filters
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny, IsAdminUser
from django_filters.rest_framework import DjangoFilterBackend
from django.db.models import F
from .models import Contest, Contestant, Vote
from .serializers import (ContestSerializer, ContestantSerializer,
                          ContestantCreateSerializer, LeaderboardSerializer)


class ContestListView(generics.ListAPIView):
    queryset = Contest.objects.all()
    serializer_class = ContestSerializer
    permission_classes = [AllowAny]


class ContestDetailView(generics.RetrieveAPIView):
    queryset = Contest.objects.all()
    serializer_class = ContestSerializer
    permission_classes = [AllowAny]


class ContestantRegisterView(generics.CreateAPIView):
    serializer_class = ContestantCreateSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save()


class ContestantDetailView(generics.RetrieveAPIView):
    queryset = Contestant.objects.filter(status='approved')
    serializer_class = ContestantSerializer
    permission_classes = [AllowAny]
    lookup_field = 'slug'


class LeaderboardView(generics.ListAPIView):
    serializer_class = LeaderboardSerializer
    permission_classes = [AllowAny]
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ['contest', 'current_stage']
    ordering = ['-total_votes']

    def get_queryset(self):
        qs = Contestant.objects.filter(status='approved').select_related('user')
        # Update ranks
        for i, c in enumerate(qs, 1):
            Contestant.objects.filter(id=c.id).update(rank=i)
        return qs


class AdminContestantListView(generics.ListAPIView):
    queryset = Contestant.objects.all().select_related('user', 'contest')
    serializer_class = ContestantSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter]
    filterset_fields = ['status', 'current_stage']
    search_fields = ['user__first_name', 'user__last_name', 'contestant_code']

    def get_permissions(self):
        if not self.request.user.is_admin and not self.request.user.is_staff:
            self.permission_denied(self.request)
        return super().get_permissions()


class ApproveContestantView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        if not request.user.is_admin and not request.user.is_staff:
            return Response({'error': 'Unauthorized'}, status=403)
        try:
            c = Contestant.objects.get(id=pk)
            c.status = 'approved'
            c.save()
            return Response({'message': 'Contestant approved'})
        except Contestant.DoesNotExist:
            return Response({'error': 'Not found'}, status=404)


class RejectContestantView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, pk):
        if not request.user.is_admin and not request.user.is_staff:
            return Response({'error': 'Unauthorized'}, status=403)
        try:
            c = Contestant.objects.get(id=pk)
            c.status = 'rejected'
            c.save()
            return Response({'message': 'Contestant rejected'})
        except Contestant.DoesNotExist:
            return Response({'error': 'Not found'}, status=404)


class FlaggedVotesView(generics.ListAPIView):
    permission_classes = [IsAuthenticated]
    queryset = Vote.objects.filter(is_flagged=True).select_related('contestant', 'voter_user')
    serializer_class = LeaderboardSerializer

    def get_queryset(self):
        if not self.request.user.is_admin and not self.request.user.is_staff:
            self.permission_denied(self.request)
        from rest_framework import serializers
        from .models import Vote

        class VoteSerializer(serializers.ModelSerializer):
            class Meta:
                model = Vote
                fields = '__all__'
        self.serializer_class = VoteSerializer
        return Vote.objects.filter(is_flagged=True)
