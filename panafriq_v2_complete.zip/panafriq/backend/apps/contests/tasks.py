"""
Celery tasks for automated stage management.
Runs on schedule to eliminate contestants who didn't reach vote threshold.
"""
from celery import shared_task
from django.utils import timezone
from django.core.mail import send_mail
from django.conf import settings
import logging

logger = logging.getLogger(__name__)


@shared_task
def process_stage_eliminations():
    """
    Runs periodically. Checks if any stage has ended and eliminates
    contestants who didn't meet the minimum vote threshold.
    Stage 1: need 100 votes
    Stage 2: need 600 votes
    """
    from .models import Contest, Contestant
    from apps.notifications.tasks import send_newsletter_task

    now = timezone.now()
    updated = 0

    for contest in Contest.objects.exclude(status='ended'):

        # ── Stage 1 ended ────────────────────────────────────────────
        if contest.status == 'stage_1' and now > contest.stage_1_end:
            qualifiers = Contestant.objects.filter(
                contest=contest, status='approved',
                stage_1_votes__gte=contest.stage_1_min_votes
            )
            eliminated = Contestant.objects.filter(
                contest=contest, status='approved',
                stage_1_votes__lt=contest.stage_1_min_votes
            )
            eliminated.update(status='eliminated', eliminated_at=now)
            qualifiers.update(current_stage=2)
            contest.status = 'stage_2'
            contest.save(update_fields=['status'])
            updated += eliminated.count()
            logger.info(f"[{contest.name}] Stage 1 ended. {eliminated.count()} eliminated, {qualifiers.count()} advance.")

        # ── Stage 2 ended ────────────────────────────────────────────
        elif contest.status == 'stage_2' and now > contest.stage_2_end:
            qualifiers = Contestant.objects.filter(
                contest=contest, status='approved',
                stage_2_votes__gte=contest.stage_2_min_votes
            )
            eliminated = Contestant.objects.filter(
                contest=contest, status='approved',
                stage_2_votes__lt=contest.stage_2_min_votes
            )
            eliminated.update(status='eliminated', eliminated_at=now)
            qualifiers.update(current_stage=3)
            contest.status = 'stage_3'
            contest.save(update_fields=['status'])
            updated += eliminated.count()

        # ── Stage 3 (Finals) ended ────────────────────────────────────
        elif contest.status == 'stage_3' and now > contest.stage_3_end:
            finalists = Contestant.objects.filter(
                contest=contest, status='approved'
            ).order_by('-total_votes')

            if finalists.exists():
                # Crown the winner
                winner = finalists.first()
                winner.is_winner = True
                winner.status = 'winner'
                winner.save(update_fields=['is_winner', 'status'])

                # Mark top 10
                top10 = finalists[:10]
                for c in top10:
                    c.is_top_10 = True
                    c.save(update_fields=['is_top_10'])

                logger.info(f"[{contest.name}] Finals ended. Winner: {winner.user.get_full_name()}")

            contest.status = 'ended'
            contest.save(update_fields=['status'])

    return f"Processed eliminations. {updated} contestants eliminated."


@shared_task
def update_rankings():
    """Update contestant ranks every 5 minutes."""
    from .models import Contest, Contestant
    for contest in Contest.objects.exclude(status__in=['upcoming', 'ended']):
        contestants = Contestant.objects.filter(
            contest=contest, status='approved'
        ).order_by('-total_votes')
        for i, c in enumerate(contestants, 1):
            Contestant.objects.filter(id=c.id).update(
                rank=i, is_top_10=(i <= 10)
            )
