import logging
from django.http import JsonResponse
from django.conf import settings
from django.core.mail import send_mail
from django.utils import timezone
from .middleware import _get_ip, _send_security_alert

logger = logging.getLogger('security')


def honeypot_view(request):
    """Fake admin page — logs and alerts on any access."""
    ip = _get_ip(request)
    ua = request.META.get('HTTP_USER_AGENT', 'unknown')
    msg = (
        f"HONEYPOT HIT\n"
        f"IP: {ip}\n"
        f"Path: {request.path}\n"
        f"Method: {request.method}\n"
        f"User-Agent: {ua}\n"
        f"Time (GMT): {timezone.now().strftime('%Y-%m-%d %H:%M:%S UTC')}\n"
        f"Headers: {dict(request.headers)}"
    )
    logger.critical(msg)
    _send_security_alert('HONEYPOT ACCESS DETECTED', msg)
    # Return a convincing fake 404 — don't reveal it's a trap
    return JsonResponse({'detail': 'Not found.'}, status=404)


def lockout_response(request, credentials=None, *args, **kwargs):
    """Called by django-axes on brute-force lockout."""
    ip = _get_ip(request)
    msg = f"BRUTE FORCE LOCKOUT: IP {ip} at {timezone.now().isoformat()}"
    logger.critical(msg)
    _send_security_alert('Brute Force Lockout', msg)
    return JsonResponse(
        {'error': 'Account locked due to too many failed attempts. Try again in 1 hour.'},
        status=403
    )
