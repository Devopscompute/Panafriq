import React, { useState } from 'react'
import { createVoterSession } from '../api'
import { useAuth } from '../contexts/AuthContext'
import toast from 'react-hot-toast'

export default function AgeGate({ children }) {
  const { user } = useAuth()
  const [verified, setVerified] = useState(() => !!sessionStorage.getItem('voter_session'))
  const [form, setForm] = useState({ date_of_birth: '', email: '', country: 'NG' })
  const [loading, setLoading] = useState(false)

  if (user?.is_old_enough_to_vote !== false || verified || user) return children

  const handleSubmit = async e => {
    e.preventDefault()
    setLoading(true)
    try {
      const { data } = await createVoterSession({ ...form, fingerprint: navigator.userAgent })
      sessionStorage.setItem('voter_session', data.session_token)
      setVerified(true)
    } catch (err) {
      toast.error(err.response?.data?.error || 'Age verification failed')
    } finally { setLoading(false) }
  }

  return (
    <div style={styles.overlay}>
      <div style={styles.card}>
        <div style={styles.icon}>🗳️</div>
        <h2 style={styles.title}>Age Verification Required</h2>
        <p style={styles.sub}>You must be 16 or older to vote. Please confirm your details.</p>
        <form onSubmit={handleSubmit} style={styles.form}>
          <div style={styles.field}>
            <label style={styles.label}>Date of Birth</label>
            <input type="date" required style={styles.input}
              value={form.date_of_birth} onChange={e => setForm({ ...form, date_of_birth: e.target.value })} />
          </div>
          <div style={styles.field}>
            <label style={styles.label}>Email (optional)</label>
            <input type="email" style={styles.input} placeholder="your@email.com"
              value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} />
          </div>
          <div style={styles.field}>
            <label style={styles.label}>Country</label>
            <select style={styles.input} value={form.country} onChange={e => setForm({ ...form, country: e.target.value })}>
              <option value="NG">Nigeria 🇳🇬</option>
              <option value="GH">Ghana 🇬🇭</option>
              <option value="CM">Cameroon 🇨🇲</option>
              <option value="OTHER">Other</option>
            </select>
          </div>
          <button type="submit" disabled={loading} style={styles.btn}>
            {loading ? 'Verifying...' : 'Confirm & Continue'}
          </button>
        </form>
      </div>
    </div>
  )
}

const styles = {
  overlay: { minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', padding:20, background:'var(--dark)' },
  card: { background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:16, padding:40, maxWidth:440, width:'100%', textAlign:'center' },
  icon: { fontSize:48, marginBottom:16 },
  title: { fontSize:24, marginBottom:8, color:'var(--gold)' },
  sub: { color:'var(--muted)', fontSize:14, marginBottom:28 },
  form: { display:'flex', flexDirection:'column', gap:16, textAlign:'left' },
  field: { display:'flex', flexDirection:'column', gap:6 },
  label: { fontSize:13, color:'var(--muted)', fontWeight:500 },
  input: { padding:'12px 14px', background:'var(--dark3)', border:'1px solid var(--border)', borderRadius:8, color:'var(--text)', fontSize:14, outline:'none' },
  btn: { padding:'14px', background:'var(--gold)', color:'var(--black)', border:'none', borderRadius:8, fontWeight:700, fontSize:15, marginTop:4 },
}
