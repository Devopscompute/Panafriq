import uuid, requests, logging
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework import serializers
from django.conf import settings
from django.db import transaction as db_transaction
from django.utils import timezone
from django.core.mail import send_mail

from .models import Transaction, FraudFlag
from apps.contests.models import Contestant, Vote

logger = logging.getLogger(__name__)

CURRENCY_MAP = {
    'NG':    {'currency': 'NGN', 'name': 'Nigerian Naira',  'symbol': '₦'},
    'GH':    {'currency': 'GHS', 'name': 'Ghanaian Cedi',   'symbol': 'GH₵'},
    'CM':    {'currency': 'XAF', 'name': 'CFA Franc',       'symbol': 'XAF'},
    'OTHER': {'currency': 'NGN', 'name': 'Nigerian Naira',  'symbol': '₦'},
}
FALLBACK_RATES = {'GHS': 85.0, 'XAF': 0.87}


def _ngn_to_local(ngn_amount, local_currency):
    if local_currency == 'NGN':
        return float(ngn_amount), 1.0
    rate = FALLBACK_RATES.get(local_currency, 1.0)
    if settings.EXCHANGE_RATE_API_KEY:
        try:
            r = requests.get(
                f"https://v6.exchangerate-api.com/v6/{settings.EXCHANGE_RATE_API_KEY}/pair/NGN/{local_currency}",
                timeout=5)
            if r.status_code == 200:
                rate = r.json().get('conversion_rate', rate)
        except Exception:
            pass
    return round(float(ngn_amount) * rate, 2), rate


def _get_ip(request):
    return (request.META.get('HTTP_X_FORWARDED_FOR', '')
            or request.META.get('REMOTE_ADDR', '127.0.0.1')).split(',')[0].strip()


def _detect_fraud(ip, vote_count):
    flags = []
    window = timezone.now() - timezone.timedelta(hours=1)
    count = Transaction.objects.filter(
        ip_address=ip, created_at__gte=window, status='success').count()
    if count >= 10:
        flags.append(f"IP {ip} made {count} successful transactions in the last hour")
    if vote_count > 100_000:
        flags.append(f"Unusually large purchase: {vote_count} votes")
    return flags


class GetPricingView(APIView):
    permission_classes = [AllowAny]

    def get(self, request):
        country    = request.query_params.get('country', 'NG').upper()
        vote_count = max(1, int(request.query_params.get('votes', 1)))
        ngn_total  = settings.VOTE_PRICE_NGN * vote_count
        info       = CURRENCY_MAP.get(country, CURRENCY_MAP['OTHER'])
        local_amt, rate = _ngn_to_local(ngn_total, info['currency'])
        return Response({
            'vote_count': vote_count,
            'price_per_vote_ngn': settings.VOTE_PRICE_NGN,
            'total_ngn': ngn_total,
            'local_currency': info['currency'],
            'currency_name': info['name'],
            'currency_symbol': info['symbol'],
            'exchange_rate': rate,
            'local_amount': local_amt,
            'country': country,
        })


class InitiatePaymentView(APIView):
    """
    Creates a PENDING transaction and returns Flutterwave payment link.
    Votes are NEVER credited here. Only the webhook credits votes.
    """
    permission_classes = [AllowAny]

    def post(self, request):
        slug         = request.data.get('contestant_slug')
        vote_count   = max(1, int(request.data.get('vote_count', 1)))
        country      = request.data.get('country', 'NG').upper()
        email        = request.data.get('email', '').strip()
        voter_name   = request.data.get('voter_name', '').strip()
        session_token= request.data.get('session_token', '')
        method       = request.data.get('payment_method', 'card')

        if vote_count > 900_000:
            return Response({'error': 'Maximum 900,000 votes per transaction.'}, status=400)

        try:
            contestant = Contestant.objects.select_related('user', 'contest').get(
                slug=slug, status='approved'
            )
        except Contestant.DoesNotExist:
            return Response({'error': 'Contestant not found or not yet approved.'}, status=404)

        ip          = _get_ip(request)
        fraud_flags = _detect_fraud(ip, vote_count)
        ngn_total   = settings.VOTE_PRICE_NGN * vote_count
        info        = CURRENCY_MAP.get(country, CURRENCY_MAP['OTHER'])
        local_amt, rate = _ngn_to_local(ngn_total, info['currency'])
        ref = f"PAQ-{uuid.uuid4().hex[:14].upper()}"

        txn = Transaction.objects.create(
            contestant=contestant,
            voter_user=request.user if request.user.is_authenticated else None,
            voter_session_token=session_token,
            voter_email=email,
            voter_name=voter_name,
            vote_count=vote_count,
            amount_ngn=ngn_total,
            amount_paid=local_amt,
            currency=info['currency'],
            exchange_rate=rate,
            payment_method=method,
            payment_reference=ref,
            status='pending',
            ip_address=ip,
        )
        for flag in fraud_flags:
            FraudFlag.objects.create(transaction=txn, ip_address=ip, reason=flag)

        # Manual bank transfer
        if method == 'manual':
            return Response({
                'reference': ref,
                'method': 'manual',
                'amount_ngn': ngn_total,
                'local_amount': local_amt,
                'currency': info['currency'],
                'contestant_name': contestant.user.get_full_name(),
                'contestant_code': contestant.contestant_code,
                'bank_details': {
                    'bank': 'First Bank Nigeria',
                    'account_name': 'PanAfriq Contest Ltd',
                    'account_number': '0123456789',
                },
                'whatsapp': '+2349168372420',
                'instructions': (
                    f"1. Transfer {info['currency']} {local_amt:,.2f} to the account above.\n"
                    f"2. Use reference: {ref} as your transfer narration.\n"
                    f"3. Upload your payment screenshot below OR send to WhatsApp.\n"
                    f"4. Votes will be credited after admin verification."
                ),
            })

        # Flutterwave hosted checkout
        payload = {
            'tx_ref': ref,
            'amount': str(local_amt),
            'currency': info['currency'],
            'redirect_url': f"{settings.FRONTEND_URL}/payment/callback",
            'customer': {
                'email': email or 'voter@panafriq.com',
                'name': voter_name or 'Voter',
            },
            'customizations': {
                'title': 'PanAfriq — Vote',
                'description': (
                    f"Voting for {contestant.user.get_full_name()} "
                    f"[{contestant.abbreviation}]"
                ),
            },
            'payment_options': 'card,mobilemoney,ussd,banktransfer',
            'meta': {'reference': ref, 'contestant_slug': slug, 'vote_count': vote_count},
        }
        headers = {
            'Authorization': f"Bearer {settings.FLUTTERWAVE_SECRET_KEY}",
            'Content-Type': 'application/json',
        }
        try:
            r = requests.post('https://api.flutterwave.com/v3/payments',
                              json=payload, headers=headers, timeout=15)
            data = r.json()
            if data.get('status') == 'success':
                return Response({'payment_link': data['data']['link'], 'reference': ref})
            return Response({'error': data.get('message', 'Payment gateway error')}, status=400)
        except requests.RequestException as exc:
            return Response({'error': 'Cannot reach payment gateway.', 'detail': str(exc)}, status=503)


class UploadPaymentProofView(APIView):
    """
    Voter uploads screenshot/photo of their bank transfer.
    Triggers admin review — no votes credited until admin confirms.
    """
    permission_classes = [AllowAny]
    parser_classes_override = ['multipart/form-data']

    def post(self, request, ref):
        try:
            txn = Transaction.objects.get(payment_reference=ref)
        except Transaction.DoesNotExist:
            return Response({'error': 'Transaction not found.'}, status=404)

        if txn.status == 'success':
            return Response({'error': 'Transaction already confirmed.'}, status=400)

        proof = request.FILES.get('proof')
        if not proof:
            return Response({'error': 'Payment proof image is required.'}, status=400)

        # Validate file type
        allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg']
        if proof.content_type not in allowed:
            return Response({'error': 'Only JPEG/PNG/WEBP images accepted.'}, status=400)

        # Max 5MB
        if proof.size > 5 * 1024 * 1024:
            return Response({'error': 'Image must be under 5MB.'}, status=400)

        txn.payment_proof    = proof
        txn.proof_uploaded_at= timezone.now()
        txn.bank_name        = request.data.get('bank_name', '').strip()
        txn.bank_account_name= request.data.get('account_name', '').strip()
        txn.transfer_amount  = request.data.get('transfer_amount') or txn.amount_paid
        txn.status           = 'manual_pending'
        txn.save()

        # Email admin
        try:
            send_mail(
                subject=f'[PanAfriq] Payment Proof Uploaded — {ref}',
                message=(
                    f"A payment proof has been uploaded for verification.\n\n"
                    f"Reference: {ref}\n"
                    f"Contestant: {txn.contestant.user.get_full_name()} [{txn.contestant.abbreviation}]\n"
                    f"Votes: {txn.vote_count:,}\n"
                    f"Amount: {txn.currency} {txn.amount_paid}\n"
                    f"Voter: {txn.voter_name or txn.voter_email or 'Anonymous'}\n"
                    f"Bank: {txn.bank_name}\n\n"
                    f"Please log in to the admin panel to verify and confirm."
                ),
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[settings.ADMIN_EMAIL],
                fail_silently=True,
            )
        except Exception:
            pass

        return Response({
            'message': 'Payment proof uploaded. An admin will verify within 30 minutes.',
            'reference': ref,
            'status': 'manual_pending',
        })


class FlutterwaveWebhookView(APIView):
    """
    THE ONLY PLACE VOTES ARE EVER CREDITED AUTOMATICALLY.
    Flutterwave fires this after a confirmed payment.
    """
    permission_classes = [AllowAny]

    def post(self, request):
        # Step 1: Verify signature
        expected = settings.FLUTTERWAVE_SECRET_HASH
        received = request.headers.get('verif-hash', '')
        if expected and received != expected:
            logger.warning(f"Webhook: invalid signature from {_get_ip(request)}")
            return Response({'status': 'invalid'}, status=401)

        event   = request.data.get('event', '')
        payload = request.data.get('data', {})
        if event != 'charge.completed':
            return Response({'status': 'ignored'})

        tx_ref = payload.get('tx_ref', '')
        flw_id = payload.get('id', '')

        # Step 2: Load transaction
        try:
            txn = Transaction.objects.select_for_update().get(payment_reference=tx_ref)
        except Transaction.DoesNotExist:
            return Response({'status': 'not found'}, status=404)

        if txn.status == 'success':
            return Response({'status': 'already processed'})

        # Step 3: Re-verify with Flutterwave
        if not self._verify_with_flutterwave(flw_id, txn):
            txn.status = 'failed'
            txn.save(update_fields=['status'])
            return Response({'status': 'verification failed'}, status=400)

        # Step 4: Credit votes atomically
        with db_transaction.atomic():
            txn.status = 'success'
            txn.flutterwave_txn_id = str(flw_id)
            txn.save(update_fields=['status', 'flutterwave_txn_id', 'updated_at'])
            self._credit_votes(txn)

        return Response({'status': 'votes credited'})

    def _verify_with_flutterwave(self, flw_id, txn):
        if not settings.FLUTTERWAVE_SECRET_KEY or not flw_id:
            return False
        try:
            r = requests.get(
                f"https://api.flutterwave.com/v3/transactions/{flw_id}/verify",
                headers={'Authorization': f"Bearer {settings.FLUTTERWAVE_SECRET_KEY}"},
                timeout=10
            )
            data = r.json()
            if data.get('status') != 'success':
                return False
            d = data['data']
            if d.get('status') != 'successful':
                return False
            paid     = float(d.get('amount', 0))
            expected = float(txn.amount_paid)
            if paid < expected * 0.99:
                FraudFlag.objects.create(
                    transaction=txn, ip_address=txn.ip_address,
                    reason=f"Amount mismatch: expected {expected}, got {paid}"
                )
                return False
            return True
        except Exception as e:
            logger.error(f"FLW verify error: {e}")
            return False

    def _credit_votes(self, txn):
        contestant = txn.contestant
        contest    = contestant.contest
        stage      = contestant.current_stage
        Vote.objects.create(
            contestant=contestant,
            voter_user=txn.voter_user,
            vote_count=txn.vote_count,
            stage=stage,
            ip_address=txn.ip_address or '0.0.0.0',
            payment_reference=txn.payment_reference,
        )
        contestant.total_votes += txn.vote_count
        if stage == 1:
            contestant.stage_1_votes += txn.vote_count
            if contestant.stage_1_votes >= contest.stage_1_min_votes:
                contestant.current_stage = 2
        elif stage == 2:
            contestant.stage_2_votes += txn.vote_count
            if contestant.stage_2_votes >= contest.stage_2_min_votes:
                contestant.current_stage = 3
        else:
            contestant.stage_3_votes += txn.vote_count
        contestant.save()


class VerifyPaymentView(APIView):
    """Frontend polls this — status is authoritative from DB (set by webhook)."""
    permission_classes = [AllowAny]

    def get(self, request):
        ref = request.query_params.get('reference', '').strip()
        if not ref:
            return Response({'error': 'reference required'}, status=400)
        try:
            txn = Transaction.objects.get(payment_reference=ref)
            return Response({
                'status': txn.status,
                'vote_count': txn.vote_count,
                'contestant': txn.contestant.slug,
                'currency': txn.currency,
                'amount': float(txn.amount_paid),
            })
        except Transaction.DoesNotExist:
            return Response({'error': 'Not found'}, status=404)


class ManualPaymentConfirmView(APIView):
    """Admin confirms a manual payment after reviewing the uploaded proof."""
    permission_classes = [IsAuthenticated]

    def post(self, request, ref):
        if not (request.user.is_admin or request.user.is_staff):
            return Response({'error': 'Admin access required.'}, status=403)
        try:
            txn = Transaction.objects.get(payment_reference=ref)
        except Transaction.DoesNotExist:
            return Response({'error': 'Transaction not found.'}, status=404)

        if txn.status == 'success':
            return Response({'error': 'Already confirmed.'}, status=400)

        action = request.data.get('action', 'confirm')  # confirm or reject

        if action == 'reject':
            txn.status = 'manual_rejected'
            txn.admin_note = request.data.get('note', 'Payment proof rejected by admin.')
            txn.admin_confirmed_by = request.user
            txn.admin_confirmed_at = timezone.now()
            txn.save()
            return Response({'message': 'Payment rejected. Voter will be notified.'})

        # Confirm
        with db_transaction.atomic():
            txn.status = 'success'
            txn.admin_note = request.data.get('note', 'Manually confirmed after proof verification.')
            txn.admin_confirmed_by = request.user
            txn.admin_confirmed_at = timezone.now()
            txn.save()
            FlutterwaveWebhookView()._credit_votes(txn)

        return Response({
            'message': f"{txn.vote_count:,} votes credited to {txn.contestant.user.get_full_name()}.",
            'contestant': txn.contestant.abbreviation,
        })


class ManualPaymentRejectView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request, ref):
        if not (request.user.is_admin or request.user.is_staff):
            return Response({'error': 'Admin access required.'}, status=403)
        try:
            txn = Transaction.objects.get(payment_reference=ref)
            txn.status = 'manual_rejected'
            txn.admin_note = request.data.get('reason', 'Proof not valid.')
            txn.admin_confirmed_by = request.user
            txn.admin_confirmed_at = timezone.now()
            txn.save()
            return Response({'message': 'Payment rejected.'})
        except Transaction.DoesNotExist:
            return Response({'error': 'Not found.'}, status=404)


class AdminTransactionListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        if not (request.user.is_admin or request.user.is_staff):
            return Response({'error': 'Admin access required.'}, status=403)

        status_filter = request.query_params.get('status', '')
        qs = Transaction.objects.all().select_related('contestant__user').order_by('-created_at')
        if status_filter:
            qs = qs.filter(status=status_filter)

        class TxnSerializer(serializers.ModelSerializer):
            contestant_name = serializers.SerializerMethodField()
            contestant_code = serializers.SerializerMethodField()
            proof_url       = serializers.SerializerMethodField()
            def get_contestant_name(self, obj): return obj.contestant.user.get_full_name()
            def get_contestant_code(self, obj): return obj.contestant.abbreviation
            def get_proof_url(self, obj):
                if obj.payment_proof:
                    return request.build_absolute_uri(obj.payment_proof.url)
                return None
            class Meta:
                model = Transaction
                fields = [
                    'id', 'contestant_name', 'contestant_code', 'voter_name',
                    'voter_email', 'vote_count', 'amount_ngn', 'amount_paid',
                    'currency', 'payment_method', 'payment_reference', 'status',
                    'proof_url', 'bank_name', 'bank_account_name', 'transfer_amount',
                    'proof_uploaded_at', 'admin_note', 'admin_confirmed_at', 'created_at',
                ]

        return Response(TxnSerializer(qs, many=True).data)
