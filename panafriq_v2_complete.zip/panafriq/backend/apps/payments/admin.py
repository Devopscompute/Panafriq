from django.contrib import admin
from .models import Transaction, FraudFlag

@admin.register(Transaction)
class TransactionAdmin(admin.ModelAdmin):
    list_display = ['payment_reference', 'contestant', 'vote_count', 'amount_ngn', 'currency', 'payment_method', 'status', 'created_at']
    list_filter = ['status', 'payment_method', 'currency']
    search_fields = ['payment_reference', 'voter_email']
    actions = ['mark_success']
    def mark_success(self, request, queryset):
        queryset.update(status='success')

@admin.register(FraudFlag)
class FraudFlagAdmin(admin.ModelAdmin):
    list_display = ['transaction', 'ip_address', 'reason', 'is_resolved', 'created_at']
    list_filter = ['is_resolved']
