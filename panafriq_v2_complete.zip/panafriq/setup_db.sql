-- Run this in MySQL before starting Django
CREATE DATABASE IF NOT EXISTS panafriq_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'panafriq_user'@'localhost' IDENTIFIED BY 'StrongPass123!';
GRANT ALL PRIVILEGES ON panafriq_db.* TO 'panafriq_user'@'localhost';
FLUSH PRIVILEGES;
