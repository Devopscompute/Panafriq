from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import timedelta
from apps.contests.models import Contest


class Command(BaseCommand):
    help = 'Seed a sample contest for development'

    def handle(self, *args, **options):
        now = timezone.now()
        contest, created = Contest.objects.get_or_create(
            name='PanAfriq Contest 2025',
            defaults={
                'description': "Africa's Premier Contest — Rise, Compete, Conquer.",
                'status': 'stage_1',
                'stage_1_start':  now,
                'stage_1_end':    now + timedelta(weeks=2),
                'stage_2_start':  now + timedelta(weeks=2),
                'stage_2_end':    now + timedelta(weeks=4),
                'stage_3_start':  now + timedelta(weeks=4),
                'stage_3_end':    now + timedelta(weeks=6),
                'stage_1_min_votes': 100,
                'stage_2_min_votes': 600,
                'prize_description': '1st: ₦500,000 + Crown | 2nd: ₦200,000 | 3rd: ₦100,000 | 4th-10th: Compensation Prizes',
                'top_10_compensation': 'Every contestant in the top 10 receives special recognition and compensation prizes.',
            }
        )
        self.stdout.write(self.style.SUCCESS(
            f"{'Created' if created else 'Already exists'}: {contest.name}"
        ))
