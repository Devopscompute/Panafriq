import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { getLeaderboard, getContests, subscribe } from '../api'
import ContestantCard from '../components/ContestantCard'
import AfricaMap from '../components/AfricaMap'
import { Trophy, Star, ChevronRight, Zap, Shield, Globe } from 'lucide-react'
import toast from 'react-hot-toast'

export default function Landing() {
  const [contestants, setContestants] = useState([])
  const [contest, setContest]         = useState(null)
  const [timeLeft, setTimeLeft]       = useState({})
  const [email, setEmail]             = useState('')
  const [subLoading, setSubLoading]   = useState(false)
  const [gmtTime, setGmtTime]         = useState(new Date())

  useEffect(() => {
    Promise.all([getLeaderboard({ page_size: 12 }), getContests()])
      .then(([lb, ct]) => {
        setContestants(lb.data.results || lb.data)
        const c = (ct.data.results || ct.data)?.[0]
        setContest(c)
      })
      .catch(() => {})
  }, [])

  // Real GMT clock
  useEffect(() => {
    const id = setInterval(() => setGmtTime(new Date()), 1000)
    return () => clearInterval(id)
  }, [])

  // Countdown in GMT
  useEffect(() => {
    if (!contest) return
    const end = new Date(contest.stage_1_end)
    const tick = () => {
      const diff = end - Date.now()
      if (diff <= 0) return setTimeLeft({ d:0,h:0,m:0,s:0 })
      setTimeLeft({
        d: Math.floor(diff/86400000),
        h: Math.floor((diff%86400000)/3600000),
        m: Math.floor((diff%3600000)/60000),
        s: Math.floor((diff%60000)/1000),
      })
    }
    tick()
    const id = setInterval(tick, 1000)
    return () => clearInterval(id)
  }, [contest])

  const handleSubscribe = async e => {
    e.preventDefault()
    if (!email) return
    setSubLoading(true)
    try {
      await subscribe(email)
      toast.success('Subscribed! You\'ll receive all contest updates.')
      setEmail('')
    } catch { toast.error('Could not subscribe. Try again.') }
    finally { setSubLoading(false) }
  }

  const gmtStr = gmtTime.toUTCString().replace('GMT', 'GMT')

  return (
    <div>
      {/* GMT Clock Banner */}
      <div style={s.gmtBar}>
        <span>🌍 Live GMT Time: <strong>{gmtStr}</strong></span>
        <span style={{ marginLeft:16, color:'var(--gold)' }}>PanAfriq — Africa's Premier Contest</span>
      </div>

      {/* HERO */}
      <section style={s.hero}>
        <div style={s.heroBg}/>
        <div style={s.heroGrid}>
          <div style={s.heroLeft}>
            <div style={s.pill}><Star size={12} fill="var(--gold)" color="var(--gold)"/> Live Now — Ages 16+</div>
            <h1 style={s.heroTitle}>
              Rise. Compete.<br/>
              <span style={{ color:'var(--gold)' }}>Conquer Africa.</span>
            </h1>
            <p style={s.heroSub}>
              PanAfriq is the continent's most electrifying voting contest — open to bold, ambitious individuals ready to claim their crown. 
              Every vote is a statement. Every supporter is your army. 
              <strong style={{ color:'var(--gold)' }}> ₦50 = 1 vote.</strong> Highest votes wins.
            </p>
            <div style={s.heroBtns}>
              <Link to="/register" style={s.btnGold}>Join the Contest</Link>
              <Link to="/leaderboard" style={s.btnOutline}>Live Leaderboard</Link>
            </div>
            <div style={s.badges}>
              <span style={s.badge}><Shield size={12}/> 16+ Only</span>
              <span style={s.badge}><Globe size={12}/> NG · GH · CM</span>
              <span style={s.badge}><Zap size={12}/> Instant Votes</span>
            </div>
          </div>
          <div style={s.heroRight}>
            <AfricaMap style={{ width:'100%', maxWidth:360, opacity:0.9 }}/>
          </div>
        </div>

        {/* Countdown */}
        {contest && (
          <div style={s.countdown}>
            <p style={s.countdownLabel}>⏱ Stage 1 Ends In (GMT)</p>
            <div style={s.timerRow}>
              {[['d','Days'],['h','Hrs'],['m','Min'],['s','Sec']].map(([k,l]) => (
                <div key={k} style={s.timerBox}>
                  <span style={s.timerNum}>{String(timeLeft[k]??0).padStart(2,'0')}</span>
                  <span style={s.timerLabel}>{l}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </section>

      {/* HOW IT WORKS */}
      <section style={s.section}>
        <h2 style={s.sectionTitle}>How It Works</h2>
        <div style={s.steps}>
          {[
            { icon:'📝', n:1, title:'Register (16+)', desc:'Create your account, upload your best photo and a compelling bio. Your unique link is generated instantly.' },
            { icon:'🔗', n:2, title:'Get Your Link', desc:'Every contestant receives a unique voting link. Example: panafriq.com/vote/your-name' },
            { icon:'📢', n:3, title:'Campaign Hard', desc:'Share across WhatsApp, Instagram, TikTok, Facebook. Mobilise your supporters — every vote counts!' },
            { icon:'🗳️', n:4, title:'Votes Win Stages', desc:'100 votes advances you to Stage 2. 600 votes to the Finals. Most votes in Finals = WINNER!' },
          ].map((s2, i) => (
            <div key={i} style={s.stepCard}>
              <div style={s.stepN}>{s2.n}</div>
              <div style={s.stepIcon}>{s2.icon}</div>
              <h3 style={s.stepTitle}>{s2.title}</h3>
              <p style={s.stepDesc}>{s2.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* STAGES */}
      <section style={{ ...s.section, background:'var(--dark2)', maxWidth:'100%', padding:'60px 24px' }}>
        <div style={{ maxWidth:1100, margin:'0 auto' }}>
          <h2 style={s.sectionTitle}>Contest Stages</h2>
          <div style={s.stageRow}>
            {[
              { n:1, title:'Stage 1',  req:'100 votes', dur:'2 Weeks', color:'#2980B9', note:'Must hit 100 or eliminated' },
              { n:2, title:'Stage 2',  req:'600 votes', dur:'2 Weeks', color:'#9B59B6', note:'Must hit 600 or eliminated' },
              { n:3, title:'🏆 Finals', req:'Most votes', dur:'2 Weeks', color:'var(--gold)', note:'Top contestant crowned WINNER' },
            ].map(st => (
              <div key={st.n} style={{ ...s.stageCard, borderColor: st.color }}>
                <div style={{ ...s.stageDot, background: st.color }}>{st.n === 3 ? '👑' : st.n}</div>
                <h3 style={{ color: st.color, marginBottom:8 }}>{st.title}</h3>
                <p style={{ fontSize:20, fontWeight:700, marginBottom:4 }}>{st.req}</p>
                <p style={{ fontSize:12, color:'var(--muted)', marginBottom:8 }}>⏱ {st.dur}</p>
                <p style={{ fontSize:12, color:'var(--muted)', fontStyle:'italic' }}>{st.note}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TOP 10 COMPENSATION */}
      <section style={s.section}>
        <div style={s.compensationBox}>
          <Trophy size={32} color="var(--gold)"/>
          <h2 style={{ fontSize:28, color:'var(--gold)', margin:'12px 0 8px' }}>Top 10 Compensation</h2>
          <p style={{ color:'var(--muted)', fontSize:15, maxWidth:600, lineHeight:1.7 }}>
            The top 10 contestants with the highest votes receive special recognition and compensation prizes — 
            even if you don't take the crown, your campaign earns real rewards.
            First place always wears the crown 👑.
          </p>
          <div style={s.compensationItems}>
            {['👑 1st Place — Grand Prize + Crown', '🥈 2nd Place — Silver Prize', '🥉 3rd Place — Bronze Prize',
              '🏅 4th–10th Place — Special Compensation Rewards'].map((item, i) => (
              <div key={i} style={s.compItem}>{item}</div>
            ))}
          </div>
        </div>
      </section>

      {/* TOP CONTESTANTS */}
      <section style={s.section}>
        <div style={s.sectionHead}>
          <h2 style={s.sectionTitle}>Live Leaderboard</h2>
          <Link to="/leaderboard" style={s.viewAll}>View All <ChevronRight size={16}/></Link>
        </div>
        <div style={s.goldBanner}>
          ✨ Top 10 contestants glow in gold — The first place always wears the crown 👑
        </div>
        <div style={s.grid}>
          {contestants.map((c, i) => (
            <ContestantCard key={c.id} contestant={c} rank={i+1}/>
          ))}
        </div>
      </section>

      {/* NEWSLETTER */}
      <section style={s.newsletter}>
        <h2 style={{ fontSize:28, color:'var(--gold)', marginBottom:8 }}>Stay Updated</h2>
        <p style={{ color:'var(--muted)', marginBottom:24, fontSize:14 }}>
          Get notified about prize changes, stage updates, and winner announcements.
        </p>
        <form onSubmit={handleSubscribe} style={s.subForm}>
          <input type="email" required placeholder="your@email.com" value={email}
            onChange={e => setEmail(e.target.value)} style={s.subInput}/>
          <button type="submit" disabled={subLoading} style={s.subBtn}>
            {subLoading ? '...' : 'Subscribe'}
          </button>
        </form>
      </section>

      {/* CTA */}
      <section style={s.cta}>
        <h2 style={s.ctaTitle}>Your Moment Is Now.</h2>
        <p style={s.ctaSub}>Join thousands of ambitious Africans competing for glory. Register today — only 16 and above.</p>
        <Link to="/register" style={s.btnGold}>Register & Get My Link →</Link>
      </section>
    </div>
  )
}

const s = {
  gmtBar: { background:'var(--dark3)', borderBottom:'1px solid var(--border)', padding:'8px 24px', fontSize:12, color:'var(--muted)', display:'flex', justifyContent:'space-between', flexWrap:'wrap', gap:8 },
  hero: { minHeight:'88vh', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', padding:'80px 24px 60px', position:'relative', overflow:'hidden' },
  heroBg: { position:'absolute', inset:0, background:'radial-gradient(ellipse 80% 60% at 50% 0%, rgba(201,168,76,0.1) 0%, transparent 70%)', pointerEvents:'none' },
  heroGrid: { display:'grid', gridTemplateColumns:'1fr 1fr', gap:48, maxWidth:1100, width:'100%', alignItems:'center', position:'relative', zIndex:1 },
  heroLeft: { display:'flex', flexDirection:'column', gap:16 },
  heroRight: { display:'flex', justifyContent:'center' },
  pill: { display:'inline-flex', alignItems:'center', gap:6, background:'rgba(201,168,76,0.1)', border:'1px solid var(--border)', borderRadius:20, padding:'6px 14px', fontSize:12, fontWeight:600, color:'var(--gold)', width:'fit-content' },
  heroTitle: { fontSize:'clamp(32px,5vw,64px)', lineHeight:1.1 },
  heroSub: { fontSize:15, color:'var(--muted)', lineHeight:1.8, maxWidth:520 },
  heroBtns: { display:'flex', gap:12, flexWrap:'wrap' },
  btnGold: { padding:'14px 28px', background:'var(--gold)', color:'var(--black)', borderRadius:10, fontWeight:700, fontSize:15 },
  btnOutline: { padding:'14px 28px', border:'1px solid var(--gold)', color:'var(--gold)', borderRadius:10, fontWeight:600, fontSize:15 },
  badges: { display:'flex', gap:8, flexWrap:'wrap' },
  badge: { display:'flex', alignItems:'center', gap:4, background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:20, padding:'4px 10px', fontSize:11, color:'var(--muted)' },
  countdown: { marginTop:48, background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:16, padding:'20px 32px', position:'relative', zIndex:1, textAlign:'center' },
  countdownLabel: { fontSize:12, color:'var(--muted)', marginBottom:12, textTransform:'uppercase', letterSpacing:1 },
  timerRow: { display:'flex', gap:16, justifyContent:'center' },
  timerBox: { display:'flex', flexDirection:'column', alignItems:'center', minWidth:60 },
  timerNum: { fontSize:36, fontWeight:700, color:'var(--gold)', fontFamily:"'Playfair Display',serif" },
  timerLabel: { fontSize:11, color:'var(--muted)', textTransform:'uppercase', letterSpacing:1 },
  section: { padding:'72px 24px', maxWidth:1200, margin:'0 auto' },
  sectionTitle: { fontSize:32, textAlign:'center', marginBottom:40 },
  sectionHead: { display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:32 },
  viewAll: { display:'flex', alignItems:'center', gap:4, color:'var(--gold)', fontSize:14, fontWeight:600 },
  steps: { display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))', gap:24 },
  stepCard: { background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:16, padding:28, textAlign:'center', position:'relative' },
  stepN: { position:'absolute', top:-14, left:'50%', transform:'translateX(-50%)', background:'var(--gold)', color:'var(--black)', width:28, height:28, borderRadius:'50%', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:700, fontSize:13 },
  stepIcon: { fontSize:36, marginBottom:12 },
  stepTitle: { fontSize:17, fontWeight:700, marginBottom:8 },
  stepDesc: { fontSize:13, color:'var(--muted)', lineHeight:1.6 },
  stageRow: { display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))', gap:24, maxWidth:900, margin:'0 auto' },
  stageCard: { background:'var(--dark3)', border:'2px solid', borderRadius:16, padding:28, textAlign:'center' },
  stageDot: { width:44, height:44, borderRadius:'50%', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:700, fontSize:18, margin:'0 auto 16px', color:'white' },
  compensationBox: { background:'linear-gradient(135deg,rgba(201,168,76,0.06),rgba(201,168,76,0.02))', border:'1px solid var(--border)', borderRadius:20, padding:40, textAlign:'center' },
  compensationItems: { display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(220px,1fr))', gap:12, marginTop:24 },
  compItem: { background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:10, padding:'12px 16px', fontSize:14, fontWeight:600 },
  goldBanner: { background:'linear-gradient(90deg,rgba(201,168,76,0.06),rgba(201,168,76,0.14),rgba(201,168,76,0.06))', border:'1px solid var(--border)', borderRadius:10, padding:'12px 20px', fontSize:13, color:'var(--gold)', textAlign:'center', marginBottom:28 },
  grid: { display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(200px,1fr))', gap:20 },
  newsletter: { background:'var(--dark2)', borderTop:'1px solid var(--border)', borderBottom:'1px solid var(--border)', padding:'60px 24px', textAlign:'center' },
  subForm: { display:'flex', gap:12, maxWidth:440, margin:'0 auto', flexWrap:'wrap', justifyContent:'center' },
  subInput: { flex:1, minWidth:220, padding:'12px 16px', background:'var(--dark3)', border:'1px solid var(--border)', borderRadius:8, color:'var(--text)', fontSize:14, outline:'none' },
  subBtn: { padding:'12px 24px', background:'var(--gold)', color:'var(--black)', border:'none', borderRadius:8, fontWeight:700 },
  cta: { background:'linear-gradient(135deg,var(--dark2),var(--dark3))', borderTop:'1px solid var(--border)', padding:'80px 24px', textAlign:'center' },
  ctaTitle: { fontSize:40, marginBottom:12, color:'var(--gold)' },
  ctaSub: { fontSize:15, color:'var(--muted)', marginBottom:28, maxWidth:500, margin:'0 auto 28px' },
}
