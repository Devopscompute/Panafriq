import React, { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { getContestant } from '../api'
import { Share2, Trophy, Copy, Check } from 'lucide-react'
import toast from 'react-hot-toast'

export default function ContestantProfile() {
  const { slug } = useParams()
  const [c, setC] = useState(null)
  const [loading, setLoading] = useState(true)
  const [copied, setCopied] = useState(false)

  useEffect(() => {
    getContestant(slug).then(r => setC(r.data)).finally(() => setLoading(false))
  }, [slug])

  const copyLink = () => {
    const url = `${window.location.origin}/vote/${slug}`
    navigator.clipboard.writeText(url)
    setCopied(true)
    toast.success('Vote link copied!')
    setTimeout(() => setCopied(false), 2000)
  }

  const shareLink = () => {
    const url = `${window.location.origin}/vote/${slug}`
    if (navigator.share) {
      navigator.share({ title: `Vote for ${c?.user?.first_name}!`, url })
    } else {
      copyLink()
    }
  }

  if (loading) return <div style={styles.loading}>Loading profile...</div>
  if (!c) return <div style={styles.loading}>Contestant not found.</div>

  const stageVotes = [c.stage_1_votes, c.stage_2_votes, c.stage_3_votes]
  const stageReqs = [100, 400, null]

  return (
    <div style={styles.page}>
      <div style={styles.container}>
        {/* Profile Header */}
        <div style={styles.header}>
          <div style={styles.photoWrap}>
            <img src={c.photo_url || '/placeholder.jpg'} alt={c.user?.first_name} style={styles.photo} />
            <div style={styles.stageBadge}>Stage {c.current_stage}</div>
          </div>
          <div style={styles.headerInfo}>
            <div style={styles.code}>{c.contestant_code}</div>
            <h1 style={styles.name}>{c.user?.first_name} {c.user?.last_name}</h1>
            <p style={styles.country}>{countryFlag(c.country)} {countryName(c.country)}</p>
            <div style={styles.totalVotes}>
              <Trophy size={20} color="var(--gold)" />
              <span style={styles.voteCount}>{c.total_votes?.toLocaleString()}</span>
              <span style={styles.voteLabel}>total votes</span>
            </div>
            {c.bio && <p style={styles.bio}>{c.bio}</p>}
            <div style={styles.btnRow}>
              <Link to={`/vote/${slug}`} style={styles.voteBtn}>🗳️ Vote Now — ₦50/vote</Link>
              <button onClick={shareLink} style={styles.shareBtn}><Share2 size={15} /> Share</button>
              <button onClick={copyLink} style={styles.copyBtn}>
                {copied ? <Check size={15} /> : <Copy size={15} />}
              </button>
            </div>
          </div>
        </div>

        {/* Stage Progress */}
        <div style={styles.stagesBox}>
          <h3 style={styles.stagesTitle}>Stage Progress</h3>
          <div style={styles.stagesGrid}>
            {[1,2,3].map(s => {
              const sv = stageVotes[s-1]
              const req = stageReqs[s-1]
              const pct = req ? Math.min(100, (sv / req) * 100) : 100
              const active = c.current_stage === s
              const done = c.current_stage > s
              return (
                <div key={s} style={{ ...styles.stageCard, ...(active ? styles.stageActive : {}), ...(done ? styles.stageDone : {}) }}>
                  <div style={styles.stageHeader}>
                    <span style={styles.stageName}>{s === 3 ? '🏆 Finals' : `Stage ${s}`}</span>
                    <span style={styles.stageStatus}>{done ? '✅ Passed' : active ? '🔥 Active' : '🔒 Locked'}</span>
                  </div>
                  <div style={styles.stageVotes}>{sv?.toLocaleString()} {req ? `/ ${req.toLocaleString()}` : ''} votes</div>
                  {req && (
                    <div style={styles.progressBar}>
                      <div style={{ ...styles.progressFill, width:`${pct}%` }} />
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </div>

        {/* Share Section */}
        <div style={styles.shareBox}>
          <h3 style={styles.shareTitle}>Help {c.user?.first_name} Win!</h3>
          <p style={styles.shareSub}>Share this voting link with friends and family</p>
          <div style={styles.linkBox}>
            <span style={styles.linkText}>{window.location.origin}/vote/{slug}</span>
            <button onClick={copyLink} style={styles.copyInline}>
              {copied ? '✓ Copied' : 'Copy'}
            </button>
          </div>
          <p style={styles.shareNote}>No account needed to vote. Anyone can vote via this link (age 16+ required).</p>
        </div>
      </div>
    </div>
  )
}

const countryFlag = c => c === 'NG' ? '🇳🇬' : c === 'GH' ? '🇬🇭' : c === 'CM' ? '🇨🇲' : '🌍'
const countryName = c => c === 'NG' ? 'Nigeria' : c === 'GH' ? 'Ghana' : c === 'CM' ? 'Cameroon' : 'Africa'

const styles = {
  page: { padding:'40px 24px', minHeight:'100vh' },
  container: { maxWidth:900, margin:'0 auto', display:'flex', flexDirection:'column', gap:28 },
  loading: { textAlign:'center', padding:80, color:'var(--muted)' },
  header: { display:'grid', gridTemplateColumns:'280px 1fr', gap:36, background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:20, padding:32 },
  photoWrap: { position:'relative', borderRadius:16, overflow:'hidden', aspectRatio:'1' },
  photo: { width:'100%', height:'100%', objectFit:'cover' },
  stageBadge: { position:'absolute', bottom:10, right:10, background:'var(--gold)', color:'var(--black)', padding:'4px 12px', borderRadius:20, fontSize:12, fontWeight:700 },
  headerInfo: { display:'flex', flexDirection:'column', gap:10 },
  code: { fontSize:12, color:'var(--gold)', fontWeight:700, letterSpacing:1, textTransform:'uppercase' },
  name: { fontSize:36, color:'var(--text)' },
  country: { fontSize:16, color:'var(--muted)' },
  totalVotes: { display:'flex', alignItems:'center', gap:8 },
  voteCount: { fontSize:32, fontWeight:700, color:'var(--gold)' },
  voteLabel: { color:'var(--muted)', fontSize:14 },
  bio: { fontSize:14, color:'var(--muted)', lineHeight:1.7, padding:'10px 0' },
  btnRow: { display:'flex', gap:10, marginTop:4, flexWrap:'wrap' },
  voteBtn: { padding:'12px 20px', background:'var(--gold)', color:'var(--black)', borderRadius:10, fontWeight:700, fontSize:14 },
  shareBtn: { padding:'12px 18px', border:'1px solid var(--border)', borderRadius:10, background:'transparent', color:'var(--text)', display:'flex', alignItems:'center', gap:6, fontSize:14 },
  copyBtn: { padding:'12px', border:'1px solid var(--border)', borderRadius:10, background:'transparent', color:'var(--muted)', display:'flex', alignItems:'center' },
  stagesBox: { background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:20, padding:28 },
  stagesTitle: { fontSize:20, marginBottom:20 },
  stagesGrid: { display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:16 },
  stageCard: { background:'var(--dark3)', border:'1px solid var(--border)', borderRadius:12, padding:20, opacity:0.7 },
  stageActive: { border:'1px solid var(--gold)', opacity:1, boxShadow:'0 0 20px rgba(201,168,76,0.2)' },
  stageDone: { opacity:0.9 },
  stageHeader: { display:'flex', justifyContent:'space-between', marginBottom:8 },
  stageName: { fontWeight:700, fontSize:15 },
  stageStatus: { fontSize:12 },
  stageVotes: { fontSize:20, fontWeight:700, color:'var(--gold)', marginBottom:8 },
  progressBar: { height:6, background:'var(--dark)', borderRadius:3, overflow:'hidden' },
  progressFill: { height:'100%', background:'linear-gradient(90deg, var(--gold-dark), var(--gold))', borderRadius:3, transition:'width 1s ease' },
  shareBox: { background:'linear-gradient(135deg, rgba(201,168,76,0.08), rgba(201,168,76,0.03))', border:'1px solid var(--border)', borderRadius:20, padding:28, textAlign:'center' },
  shareTitle: { fontSize:22, color:'var(--gold)', marginBottom:8 },
  shareSub: { color:'var(--muted)', fontSize:14, marginBottom:18 },
  linkBox: { display:'flex', alignItems:'center', background:'var(--dark3)', border:'1px solid var(--border)', borderRadius:10, overflow:'hidden', maxWidth:560, margin:'0 auto 14px' },
  linkText: { flex:1, padding:'12px 16px', fontSize:13, color:'var(--muted)', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' },
  copyInline: { padding:'12px 20px', background:'var(--gold)', color:'var(--black)', border:'none', fontWeight:700, fontSize:13, cursor:'pointer' },
  shareNote: { fontSize:12, color:'var(--muted)' },
}
