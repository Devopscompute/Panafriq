import React, { useState, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { verifyOTP, resendOTP } from '../api'
import { useAuth } from '../contexts/AuthContext'
import toast from 'react-hot-toast'

export default function VerifyOTP() {
  const nav = useNavigate()
  const { user, setUser } = useAuth()
  const [codes, setCodes] = useState(['','','','','',''])
  const [loading, setLoading] = useState(false)
  const [resending, setResending] = useState(false)
  const refs = useRef([])

  const handleChange = (i, val) => {
    if (!/^\d?$/.test(val)) return
    const next = [...codes]
    next[i] = val
    setCodes(next)
    if (val && i < 5) refs.current[i+1]?.focus()
  }

  const handleKeyDown = (i, e) => {
    if (e.key === 'Backspace' && !codes[i] && i > 0) refs.current[i-1]?.focus()
  }

  const handleSubmit = async e => {
    e.preventDefault()
    const otp = codes.join('')
    if (otp.length !== 6) { toast.error('Enter the full 6-digit code'); return }
    setLoading(true)
    try {
      await verifyOTP(otp)
      toast.success('Email verified! Your account is fully activated.')
      setUser(u => ({ ...u, email_verified: true }))
      nav('/')
    } catch (err) {
      toast.error(err.response?.data?.error || 'Invalid or expired OTP')
      setCodes(['','','','','',''])
      refs.current[0]?.focus()
    } finally { setLoading(false) }
  }

  const handleResend = async () => {
    setResending(true)
    try {
      await resendOTP()
      toast.success('New OTP sent to your email')
    } catch { toast.error('Could not resend. Try again.') }
    finally { setResending(false) }
  }

  return (
    <div style={s.page}>
      <div style={s.card}>
        <div style={{ fontSize:52, textAlign:'center', marginBottom:12 }}>📧</div>
        <h2 style={s.title}>Verify Your Email</h2>
        <p style={s.sub}>
          A 6-digit verification code was sent to <strong style={{color:'var(--gold)'}}>{user?.email}</strong>.
          Enter it below to activate your account.
        </p>
        <form onSubmit={handleSubmit} style={s.form}>
          <div style={s.otpRow}>
            {codes.map((c, i) => (
              <input
                key={i}
                ref={el => refs.current[i] = el}
                type="text" inputMode="numeric" maxLength={1}
                value={c}
                onChange={e => handleChange(i, e.target.value)}
                onKeyDown={e => handleKeyDown(i, e)}
                style={{ ...s.otpBox, ...(c ? s.otpBoxFilled : {}) }}
              />
            ))}
          </div>
          <button type="submit" disabled={loading} style={s.btn}>
            {loading ? 'Verifying...' : 'Verify Account'}
          </button>
        </form>
        <p style={s.resendText}>
          Didn't receive it?{' '}
          <button onClick={handleResend} disabled={resending} style={s.resendBtn}>
            {resending ? 'Sending...' : 'Resend OTP'}
          </button>
        </p>
        <p style={s.skip} onClick={() => nav('/')}>Skip for now →</p>
      </div>
    </div>
  )
}

const s = {
  page: { minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', padding:24 },
  card: { background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:20, padding:40, width:'100%', maxWidth:420, textAlign:'center' },
  title: { fontSize:26, color:'var(--gold)', marginBottom:8 },
  sub: { color:'var(--muted)', fontSize:14, lineHeight:1.6, marginBottom:28 },
  form: { display:'flex', flexDirection:'column', gap:20 },
  otpRow: { display:'flex', gap:10, justifyContent:'center' },
  otpBox: { width:48, height:56, textAlign:'center', fontSize:24, fontWeight:700, background:'var(--dark3)', border:'2px solid var(--border)', borderRadius:10, color:'var(--text)', outline:'none', transition:'border .2s' },
  otpBoxFilled: { borderColor:'var(--gold)', boxShadow:'0 0 8px rgba(201,168,76,0.3)' },
  btn: { padding:'14px', background:'var(--gold)', color:'var(--black)', border:'none', borderRadius:10, fontWeight:700, fontSize:15, cursor:'pointer' },
  resendText: { color:'var(--muted)', fontSize:13, marginTop:16 },
  resendBtn: { background:'none', border:'none', color:'var(--gold)', cursor:'pointer', fontWeight:600, fontSize:13 },
  skip: { color:'var(--muted)', fontSize:12, marginTop:16, cursor:'pointer', textDecoration:'underline' },
}
