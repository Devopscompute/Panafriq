from django.urls import path
from rest_framework_simplejwt.views import TokenRefreshView
from .views import (
    RegisterView, LoginView, ProfileView, CreateVoterSessionView,
    VerifyOTPView, ResendOTPView, SetupTOTPView,
    GoogleSSOView, FacebookSSOView,
)

urlpatterns = [
    path('register/',      RegisterView.as_view()),
    path('login/',         LoginView.as_view()),
    path('token/refresh/', TokenRefreshView.as_view()),
    path('profile/',       ProfileView.as_view()),
    path('voter-session/', CreateVoterSessionView.as_view()),
    # OTP / TOTP
    path('otp/verify/',    VerifyOTPView.as_view()),
    path('otp/resend/',    ResendOTPView.as_view()),
    path('totp/setup/',    SetupTOTPView.as_view()),
    # SSO
    path('sso/google/',    GoogleSSOView.as_view()),
    path('sso/facebook/',  FacebookSSOView.as_view()),
]
