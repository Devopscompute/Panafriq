import React, { useEffect, useState, useRef } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { getContestant, getPricing, initPayment, uploadProof } from '../api'
import { useAuth } from '../contexts/AuthContext'
import toast from 'react-hot-toast'
import { CreditCard, Smartphone, Building2, Upload, CheckCircle } from 'lucide-react'

const PRESETS = [1, 5, 10, 20, 50, 100, 500, 1000]

export default function VotePage() {
  const { slug } = useParams()
  const nav = useNavigate()
  const { user } = useAuth()
  const [contestant, setContestant] = useState(null)
  const [voteCount, setVoteCount]   = useState(1)
  const [custom, setCustom]         = useState('')
  const [pricing, setPricing]       = useState(null)
  const [method, setMethod]         = useState('card')
  const [country, setCountry]       = useState(user?.country || 'NG')
  const [email, setEmail]           = useState(user?.email || '')
  const [voterName, setVoterName]   = useState(user ? `${user.first_name} ${user.last_name}` : '')
  const [loading, setLoading]       = useState(false)
  const [pageLoading, setPageLoading] = useState(true)
  const [manualData, setManualData] = useState(null)
  const [proofFile, setProofFile]   = useState(null)
  const [proofUploading, setProofUploading] = useState(false)
  const [proofDone, setProofDone]   = useState(false)
  const fileRef = useRef()

  const finalVotes = parseInt(custom) || voteCount

  useEffect(() => {
    getContestant(slug).then(r => setContestant(r.data)).finally(() => setPageLoading(false))
  }, [slug])

  useEffect(() => {
    if (finalVotes < 1) return
    const t = setTimeout(() => {
      getPricing(country, finalVotes).then(r => setPricing(r.data)).catch(() => {})
    }, 400)
    return () => clearTimeout(t)
  }, [finalVotes, country])

  const handleVote = async () => {
    if (!email && !user) { toast.error('Please enter your email'); return }
    setLoading(true)
    try {
      const token = sessionStorage.getItem('voter_session') || ''
      const { data } = await initPayment({
        contestant_slug: slug,
        vote_count: finalVotes,
        country,
        email: email || user?.email,
        voter_name: voterName,
        session_token: token,
        payment_method: method,
      })
      if (method === 'manual') {
        setManualData(data)
      } else if (data.payment_link) {
        window.location.href = data.payment_link
      }
    } catch (err) {
      toast.error(err.response?.data?.error || 'Payment initiation failed')
    } finally { setLoading(false) }
  }

  const handleProofUpload = async () => {
    if (!proofFile || !manualData) { toast.error('Select a screenshot first'); return }
    setProofUploading(true)
    try {
      const fd = new FormData()
      fd.append('proof', proofFile)
      fd.append('bank_name', document.getElementById('bankName')?.value || '')
      fd.append('account_name', document.getElementById('acctName')?.value || '')
      fd.append('transfer_amount', manualData.local_amount)
      await uploadProof(manualData.reference, fd)
      setProofDone(true)
      toast.success('Proof uploaded! Admin will verify within 30 minutes.')
    } catch (err) {
      toast.error(err.response?.data?.error || 'Upload failed')
    } finally { setProofUploading(false) }
  }

  if (pageLoading) return <div style={s.loading}>Loading...</div>
  if (!contestant)  return <div style={s.loading}>Contestant not found.</div>

  // Manual payment screen
  if (manualData && !proofDone) return (
    <div style={s.page}>
      <div style={s.manualBox}>
        <h2 style={s.manualTitle}>Bank Transfer Instructions</h2>
        <div style={s.infoGrid}>
          <Info k="Contestant" v={`${manualData.contestant_name} [${manualData.contestant_code}]`}/>
          <Info k="Votes" v={finalVotes.toLocaleString()}/>
          <Info k="Reference (use as narration)" v={manualData.reference} gold/>
          <Info k="Amount" v={`${manualData.currency} ${manualData.local_amount?.toLocaleString()}`}/>
          <Info k="Bank" v={manualData.bank_details?.bank}/>
          <Info k="Account Name" v={manualData.bank_details?.account_name}/>
          <Info k="Account Number" v={manualData.bank_details?.account_number} gold/>
        </div>
        <div style={s.manualSteps}>
          {manualData.instructions?.split('\n').filter(Boolean).map((l, i) => <p key={i} style={{ marginBottom:6, fontSize:13 }}>{l}</p>)}
        </div>

        {/* Upload proof */}
        <div style={s.proofSection}>
          <h3 style={{ fontSize:16, marginBottom:12, color:'var(--gold)' }}>Upload Payment Screenshot</h3>
          <div style={s.proofField}>
            <label style={s.label}>Your Bank Name</label>
            <input id="bankName" placeholder="e.g. GTBank" style={s.input}/>
          </div>
          <div style={s.proofField}>
            <label style={s.label}>Your Account Name</label>
            <input id="acctName" placeholder="Name on your bank account" style={s.input}/>
          </div>
          <div style={s.uploadArea} onClick={() => fileRef.current?.click()}>
            {proofFile
              ? <><CheckCircle size={24} color="var(--green)"/><p>{proofFile.name}</p></>
              : <><Upload size={24} color="var(--muted)"/><p style={{ color:'var(--muted)', fontSize:13 }}>Click to upload screenshot (JPEG/PNG, max 5MB)</p></>
            }
          </div>
          <input ref={fileRef} type="file" accept="image/*" style={{ display:'none' }}
            onChange={e => setProofFile(e.target.files[0])}/>
          <button onClick={handleProofUpload} disabled={proofUploading || !proofFile} style={s.uploadBtn}>
            {proofUploading ? 'Uploading...' : '📤 Submit Payment Proof'}
          </button>
          <p style={{ fontSize:12, color:'var(--muted)', marginTop:12, textAlign:'center' }}>
            OR send screenshot to WhatsApp: <strong style={{ color:'var(--gold)' }}>{manualData.whatsapp}</strong> with reference: <strong>{manualData.reference}</strong>
          </p>
        </div>
      </div>
    </div>
  )

  if (proofDone) return (
    <div style={{ ...s.page, alignItems:'center', justifyContent:'center' }}>
      <div style={s.successBox}>
        <CheckCircle size={64} color="var(--green)"/>
        <h2 style={{ color:'var(--green)', margin:'16px 0 8px' }}>Proof Submitted!</h2>
        <p style={{ color:'var(--muted)', fontSize:14, maxWidth:360, textAlign:'center', lineHeight:1.6 }}>
          Your payment screenshot has been sent to the admin for verification.
          Votes will be credited within 30 minutes.
        </p>
        <button onClick={() => nav(`/contestant/${slug}`)} style={s.btnGold}>View Profile</button>
      </div>
    </div>
  )

  return (
    <div style={s.page}>
      <div style={s.container}>
        {/* Contestant mini bar */}
        <div style={s.contestantBar}>
          <img
            src={contestant.photo_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(contestant.user?.first_name)}&background=1A1D26&color=C9A84C&size=80`}
            style={s.miniPhoto} alt=""/>
          <div>
            <p style={{ fontSize:11, color:'var(--gold)', fontWeight:700, letterSpacing:1, marginBottom:2 }}>
              {contestant.contestant_code} — {contestant.abbreviation || ''}
            </p>
            <h2 style={{ fontSize:20, margin:'0 0 4px' }}>{contestant.user?.first_name} {contestant.user?.last_name}</h2>
            <p style={{ fontSize:12, color:'var(--muted)' }}>🏆 {Number(contestant.total_votes)?.toLocaleString()} votes — Stage {contestant.current_stage}</p>
          </div>
        </div>

        <div style={s.grid}>
          {/* LEFT */}
          <div style={s.panel}>
            <h3 style={s.panelTitle}>Select Votes</h3>

            <div style={s.field}>
              <label style={s.label}>Your Country (sets currency)</label>
              <select style={s.input} value={country} onChange={e => setCountry(e.target.value)}>
                <option value="NG">🇳🇬 Nigeria (₦)</option>
                <option value="GH">🇬🇭 Ghana (GHS)</option>
                <option value="CM">🇨🇲 Cameroon (XAF)</option>
                <option value="OTHER">🌍 Other (₦)</option>
              </select>
            </div>

            <label style={s.label}>Quick Select</label>
            <div style={s.presets}>
              {PRESETS.map(n => (
                <button key={n}
                  onClick={() => { setVoteCount(n); setCustom('') }}
                  style={{ ...s.preset, ...(voteCount===n && !custom ? s.presetActive : {}) }}>
                  {n}
                </button>
              ))}
            </div>

            <div style={s.field}>
              <label style={s.label}>Custom amount (up to 900,000)</label>
              <input type="number" min={1} max={900000} placeholder="Type number of votes"
                style={s.input} value={custom}
                onChange={e => { setCustom(e.target.value); setVoteCount(0) }}/>
            </div>

            {!user && (
              <>
                <div style={s.field}>
                  <label style={s.label}>Your Name</label>
                  <input style={s.input} placeholder="Full name" value={voterName}
                    onChange={e => setVoterName(e.target.value)}/>
                </div>
                <div style={s.field}>
                  <label style={s.label}>Your Email (for receipt)</label>
                  <input type="email" style={s.input} placeholder="your@email.com" value={email}
                    onChange={e => setEmail(e.target.value)}/>
                </div>
              </>
            )}

            <label style={s.label}>Payment Method</label>
            <div style={s.methods}>
              {[
                { id:'card',          icon:<CreditCard size={15}/>, label:'Card' },
                { id:'momo',          icon:<Smartphone size={15}/>, label:'MoMo' },
                { id:'bank_transfer', icon:<Building2 size={15}/>,  label:'Bank Transfer' },
                { id:'manual',        icon:<Upload size={15}/>,     label:'Manual + Proof' },
              ].map(m => (
                <button key={m.id} onClick={() => setMethod(m.id)}
                  style={{ ...s.methodBtn, ...(method===m.id ? s.methodActive : {}) }}>
                  {m.icon} {m.label}
                </button>
              ))}
            </div>

            {method === 'manual' && (
              <div style={s.manualNote}>
                📋 You'll receive bank details and then upload your payment screenshot for admin verification. Votes credited after confirmation.
              </div>
            )}
          </div>

          {/* RIGHT — Summary */}
          <div style={s.summary}>
            <h3 style={s.panelTitle}>Order Summary</h3>
            <SummaryRow k="Contestant" v={`${contestant.user?.first_name} ${contestant.user?.last_name}`}/>
            <SummaryRow k="Votes" v={finalVotes.toLocaleString()}/>
            <SummaryRow k="₦ per vote" v="₦50"/>
            <div style={s.divider}/>
            {pricing ? (
              <>
                <SummaryRow k="Total (NGN)" v={`₦${Number(pricing.total_ngn)?.toLocaleString()}`}/>
                {pricing.local_currency !== 'NGN' && (
                  <SummaryRow k={`You Pay (${pricing.local_currency})`} v={`${pricing.currency_symbol} ${Number(pricing.local_amount)?.toLocaleString()}`} gold/>
                )}
                {pricing.local_currency === 'NGN' && (
                  <div style={s.totalBig}>₦{Number(pricing.total_ngn)?.toLocaleString()}</div>
                )}
                {pricing.exchange_rate !== 1 && (
                  <p style={{ fontSize:11, color:'var(--muted)', textAlign:'center' }}>
                    Rate: 1 NGN = {pricing.exchange_rate} {pricing.local_currency}
                  </p>
                )}
              </>
            ) : <div style={{ color:'var(--muted)', textAlign:'center', padding:16, fontSize:13 }}>Calculating...</div>}

            <div style={s.webhookNote}>
              🔒 Votes credited automatically via Flutterwave webhook after payment confirmation.
            </div>

            <button onClick={handleVote} disabled={loading || finalVotes < 1} style={s.payBtn}>
              {loading ? 'Processing...' : `Pay & Vote ${finalVotes.toLocaleString()} Votes`}
            </button>
            <p style={{ textAlign:'center', fontSize:11, color:'var(--muted)', marginTop:8 }}>
              Secured by Flutterwave ⚡
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

function SummaryRow({ k, v, gold }) {
  return (
    <div style={{ display:'flex', justifyContent:'space-between', marginBottom:8 }}>
      <span style={{ fontSize:13, color:'var(--muted)' }}>{k}</span>
      <span style={{ fontSize:14, fontWeight:600, color: gold ? 'var(--gold)' : 'var(--text)' }}>{v}</span>
    </div>
  )
}
function Info({ k, v, gold }) {
  return (
    <div style={{ padding:'10px 0', borderBottom:'1px solid var(--border)' }}>
      <p style={{ fontSize:11, color:'var(--muted)', marginBottom:2 }}>{k}</p>
      <p style={{ fontWeight:600, fontSize:14, color: gold ? 'var(--gold)' : 'var(--text)', fontFamily: gold ? 'monospace' : 'inherit' }}>{v}</p>
    </div>
  )
}

const s = {
  page: { padding:'40px 24px', minHeight:'100vh', display:'flex', flexDirection:'column' },
  container: { maxWidth:900, margin:'0 auto', width:'100%', display:'flex', flexDirection:'column', gap:24 },
  loading: { textAlign:'center', padding:80, color:'var(--muted)' },
  contestantBar: { display:'flex', alignItems:'center', gap:16, background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:16, padding:20 },
  miniPhoto: { width:72, height:72, borderRadius:12, objectFit:'cover', border:'2px solid var(--gold)' },
  grid: { display:'grid', gridTemplateColumns:'1fr 320px', gap:24, alignItems:'start' },
  panel: { background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:16, padding:28, display:'flex', flexDirection:'column', gap:16 },
  panelTitle: { fontSize:18, fontWeight:700 },
  field: { display:'flex', flexDirection:'column', gap:6 },
  label: { fontSize:13, color:'var(--muted)', fontWeight:500 },
  input: { padding:'12px 14px', background:'var(--dark3)', border:'1px solid var(--border)', borderRadius:8, color:'var(--text)', fontSize:14, outline:'none' },
  presets: { display:'flex', flexWrap:'wrap', gap:8 },
  preset: { padding:'8px 14px', background:'var(--dark3)', border:'1px solid var(--border)', borderRadius:8, color:'var(--muted)', fontSize:13 },
  presetActive: { background:'rgba(201,168,76,0.15)', border:'1px solid var(--gold)', color:'var(--gold)', fontWeight:700 },
  methods: { display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 },
  methodBtn: { padding:'10px 8px', background:'var(--dark3)', border:'1px solid var(--border)', borderRadius:8, color:'var(--muted)', fontSize:12, display:'flex', alignItems:'center', justifyContent:'center', gap:6 },
  methodActive: { border:'1px solid var(--gold)', color:'var(--gold)', background:'rgba(201,168,76,0.08)' },
  manualNote: { background:'rgba(201,168,76,0.06)', border:'1px solid var(--border)', borderRadius:8, padding:12, fontSize:12, color:'var(--muted)', lineHeight:1.6 },
  summary: { background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:16, padding:24, position:'sticky', top:80 },
  divider: { height:1, background:'var(--border)', margin:'8px 0' },
  totalBig: { fontSize:32, fontWeight:800, color:'var(--gold)', textAlign:'center', margin:'8px 0' },
  webhookNote: { background:'rgba(46,204,113,0.08)', border:'1px solid rgba(46,204,113,0.2)', borderRadius:8, padding:10, fontSize:11, color:'#2ECC71', lineHeight:1.5, margin:'8px 0' },
  payBtn: { padding:'14px', background:'var(--gold)', color:'var(--black)', border:'none', borderRadius:10, fontWeight:800, fontSize:15, cursor:'pointer', width:'100%' },
  manualBox: { maxWidth:600, margin:'0 auto', width:'100%', background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:20, padding:32 },
  manualTitle: { fontSize:24, color:'var(--gold)', marginBottom:20 },
  infoGrid: { marginBottom:20 },
  manualSteps: { background:'var(--dark3)', borderRadius:10, padding:16, marginBottom:20, fontSize:13, lineHeight:1.8, color:'var(--muted)' },
  proofSection: { borderTop:'1px solid var(--border)', paddingTop:20 },
  proofField: { display:'flex', flexDirection:'column', gap:6, marginBottom:14 },
  uploadArea: { background:'var(--dark3)', border:'2px dashed var(--border)', borderRadius:10, padding:28, textAlign:'center', cursor:'pointer', display:'flex', flexDirection:'column', alignItems:'center', gap:10, marginBottom:16 },
  uploadBtn: { width:'100%', padding:'13px', background:'var(--gold)', color:'var(--black)', border:'none', borderRadius:10, fontWeight:700, fontSize:14, cursor:'pointer' },
  successBox: { background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:20, padding:40, display:'flex', flexDirection:'column', alignItems:'center', gap:12, maxWidth:420, textAlign:'center' },
  btnGold: { padding:'12px 28px', background:'var(--gold)', color:'var(--black)', borderRadius:10, fontWeight:700, fontSize:14, marginTop:8 },
}
