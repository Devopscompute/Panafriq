from django.contrib import admin
from .models import Contest, Contestant, Vote

@admin.register(Contest)
class ContestAdmin(admin.ModelAdmin):
    list_display = ['name', 'status', 'stage_1_start', 'stage_3_end']
    list_filter = ['status']

@admin.register(Contestant)
class ContestantAdmin(admin.ModelAdmin):
    list_display = ['contestant_code', 'user', 'contest', 'total_votes', 'status', 'current_stage']
    list_filter = ['status', 'current_stage', 'contest']
    search_fields = ['user__first_name', 'user__last_name', 'contestant_code']
    actions = ['approve_selected', 'reject_selected']

    def approve_selected(self, request, queryset):
        queryset.update(status='approved')
    def reject_selected(self, request, queryset):
        queryset.update(status='rejected')

@admin.register(Vote)
class VoteAdmin(admin.ModelAdmin):
    list_display = ['contestant', 'vote_count', 'stage', 'ip_address', 'is_flagged', 'created_at']
    list_filter = ['stage', 'is_flagged']
