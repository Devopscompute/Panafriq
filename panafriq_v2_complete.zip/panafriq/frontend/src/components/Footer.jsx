import React from 'react'
import { Link } from 'react-router-dom'
import { Trophy } from 'lucide-react'

export default function Footer() {
  return (
    <footer style={s.footer}>
      <div style={s.inner}>
        <div style={s.brand}>
          <Trophy size={20} color="var(--gold)" />
          <span style={s.logo}>Pan<span style={{ color:'var(--gold)' }}>Afriq</span></span>
          <p style={s.tagline}>Africa's Premier Kids Contest Platform</p>
        </div>
        <div style={s.cols}>
          <div style={s.col}>
            <h4 style={s.colHead}>Platform</h4>
            <Link to="/" style={s.link}>Home</Link>
            <Link to="/leaderboard" style={s.link}>Leaderboard</Link>
            <Link to="/join-contest" style={s.link}>Join Contest</Link>
          </div>
          <div style={s.col}>
            <h4 style={s.colHead}>Account</h4>
            <Link to="/register" style={s.link}>Register</Link>
            <Link to="/login" style={s.link}>Login</Link>
          </div>
          <div style={s.col}>
            <h4 style={s.colHead}>Support</h4>
            <p style={s.link}>hello@panafriq.com</p>
            <p style={s.link}>WhatsApp: +234 916 837 2420</p>
          </div>
        </div>
      </div>
      <div style={s.bottom}>
        <p style={{ color:'var(--muted)', fontSize:12 }}>
          © {new Date().getFullYear()} PanAfriq Contest. All rights reserved. | Payments secured by Flutterwave
        </p>
      </div>
    </footer>
  )
}

const s = {
  footer: { background:'var(--black)', borderTop:'1px solid var(--border)', marginTop:80 },
  inner: { maxWidth:1200, margin:'0 auto', padding:'48px 24px 24px', display:'grid', gridTemplateColumns:'1fr 2fr', gap:48 },
  brand: { display:'flex', flexDirection:'column', gap:8 },
  logo: { fontSize:20, fontFamily:"'Playfair Display',serif", fontWeight:700 },
  tagline: { fontSize:13, color:'var(--muted)', lineHeight:1.6 },
  cols: { display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:32 },
  col: { display:'flex', flexDirection:'column', gap:10 },
  colHead: { fontSize:12, color:'var(--gold)', fontWeight:700, textTransform:'uppercase', letterSpacing:1, marginBottom:4 },
  link: { fontSize:13, color:'var(--muted)', textDecoration:'none' },
  bottom: { borderTop:'1px solid var(--border)', padding:'16px 24px', textAlign:'center' },
}
