from rest_framework.views import exception_handler
from rest_framework.response import Response


def custom_exception_handler(exc, context):
    """Strip internal details from error responses in production."""
    response = exception_handler(exc, context)
    if response is not None:
        # Never expose stack traces or internal field names in production
        from django.conf import settings
        if not settings.DEBUG and response.status_code >= 500:
            response.data = {'error': 'Internal server error. Please try again.'}
    return response
