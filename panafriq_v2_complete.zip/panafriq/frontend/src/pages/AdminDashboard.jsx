import React, { useEffect, useState } from 'react'
import { adminGetContestants, approveContestant, rejectContestant, adminTransactions, confirmManual, rejectManual, sendNewsletter } from '../api'
import { CheckCircle, XCircle, Users, DollarSign, AlertTriangle, Mail, Eye, Download } from 'lucide-react'
import toast from 'react-hot-toast'

const TABS = ['Contestants', 'Transactions', 'Manual Payments', 'Newsletter']

export default function AdminDashboard() {
  const [tab, setTab]           = useState(0)
  const [contestants, setContestants] = useState([])
  const [transactions, setTransactions] = useState([])
  const [manualPending, setManualPending] = useState([])
  const [statusFilter, setStatusFilter] = useState('pending')
  const [loading, setLoading]   = useState(false)
  const [newsletter, setNewsletter] = useState({ subject:'', body:'' })
  const [sending, setSending]   = useState(false)
  const [proofModal, setProofModal] = useState(null)

  useEffect(() => { fetchContestants() }, [statusFilter])
  useEffect(() => {
    if (tab === 1) fetchTransactions('')
    if (tab === 2) fetchTransactions('manual_pending')
  }, [tab])

  const fetchContestants = async () => {
    setLoading(true)
    try {
      const r = await adminGetContestants({ status: statusFilter || undefined })
      setContestants(r.data.results || r.data)
    } finally { setLoading(false) }
  }

  const fetchTransactions = async (statusParam) => {
    setLoading(true)
    try {
      const r = await adminTransactions({ status: statusParam })
      const data = r.data.results || r.data
      if (statusParam === 'manual_pending') setManualPending(data)
      else setTransactions(data)
    } finally { setLoading(false) }
  }

  const handleApprove = async id => {
    try { await approveContestant(id); toast.success('Approved!'); fetchContestants() }
    catch { toast.error('Failed') }
  }
  const handleReject = async id => {
    try { await rejectContestant(id); toast.success('Rejected'); fetchContestants() }
    catch { toast.error('Failed') }
  }
  const handleConfirmPayment = async (ref, note) => {
    try {
      const { data } = await confirmManual(ref, { action:'confirm', note })
      toast.success(data.message)
      fetchTransactions('manual_pending')
    } catch (err) { toast.error(err.response?.data?.error || 'Failed') }
  }
  const handleRejectPayment = async (ref) => {
    const reason = prompt('Reason for rejection:')
    if (!reason) return
    try {
      await rejectManual(ref, reason)
      toast.success('Payment rejected')
      fetchTransactions('manual_pending')
    } catch { toast.error('Failed') }
  }
  const handleNewsletter = async e => {
    e.preventDefault()
    setSending(true)
    try {
      const { data } = await sendNewsletter(newsletter)
      toast.success(data.message)
      setNewsletter({ subject:'', body:'' })
    } catch (err) { toast.error(err.response?.data?.error || 'Failed') }
    finally { setSending(false) }
  }

  const statsData = [
    { icon:<Users size={20}/>, label:'Pending Approval', value: contestants.filter(c=>c.status==='pending').length, color:'#F39C12' },
    { icon:<CheckCircle size={20}/>, label:'Approved', value: contestants.filter(c=>c.status==='approved').length, color:'var(--green)' },
    { icon:<DollarSign size={20}/>, label:'Manual Pending', value: manualPending.length, color:'var(--gold)' },
    { icon:<AlertTriangle size={20}/>, label:'Transactions', value: transactions.length, color:'#3498DB' },
  ]

  return (
    <div style={s.page}>
      <div style={s.container}>
        <div style={s.header}>
          <h1 style={s.title}>Admin Dashboard</h1>
          <p style={s.sub}>PanAfriq — Secure Admin Panel</p>
        </div>

        {/* Stats */}
        <div style={s.statsGrid}>
          {statsData.map((st, i) => (
            <div key={i} style={{ ...s.statCard, borderColor: st.color }}>
              <div style={{ color: st.color }}>{st.icon}</div>
              <div style={{ fontSize:32, fontWeight:800, color: st.color }}>{st.value}</div>
              <div style={{ fontSize:12, color:'var(--muted)' }}>{st.label}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div style={s.tabs}>
          {TABS.map((t, i) => (
            <button key={i} onClick={() => setTab(i)}
              style={{ ...s.tab, ...(tab===i ? s.tabActive : {}) }}>
              {t}
              {i===2 && manualPending.length > 0 && (
                <span style={s.badge}>{manualPending.length}</span>
              )}
            </button>
          ))}
        </div>

        {/* CONTESTANTS */}
        {tab === 0 && (
          <div>
            <div style={s.filterRow}>
              {['pending','approved','rejected','eliminated',''].map((st, i) => (
                <button key={i} onClick={() => setStatusFilter(st)}
                  style={{ ...s.filterBtn, ...(statusFilter===st ? s.filterActive : {}) }}>
                  {['Pending','Approved','Rejected','Eliminated','All'][i]}
                </button>
              ))}
            </div>
            <div style={s.tableWrap}>
              <div style={{ ...s.thead, gridTemplateColumns:'2fr 1fr 1fr 1fr 1fr 1fr 2fr' }}>
                {['Contestant','Code','Country','Stage','Votes','Status','Actions'].map(h => (
                  <div key={h} style={s.th}>{h}</div>
                ))}
              </div>
              {loading ? <div style={s.empty}>Loading...</div> : contestants.length === 0 ? <div style={s.empty}>No contestants found</div> :
                contestants.map(c => (
                  <div key={c.id} style={{ ...s.trow, gridTemplateColumns:'2fr 1fr 1fr 1fr 1fr 1fr 2fr' }}>
                    <div style={s.td}>
                      <img src={c.photo_url || '/placeholder.jpg'} style={s.thumb} alt=""/>
                      <div>
                        <div style={{ fontWeight:600, fontSize:13 }}>{c.user?.first_name} {c.user?.last_name}</div>
                        <div style={{ fontSize:11, color:'var(--muted)' }}>{c.user?.email}</div>
                      </div>
                    </div>
                    <div style={s.td}><span style={s.codeBadge}>{c.contestant_code}</span></div>
                    <div style={s.td}>{c.user?.country}</div>
                    <div style={s.td}>Stage {c.current_stage}</div>
                    <div style={s.td}><strong style={{ color:'var(--gold)' }}>{c.total_votes?.toLocaleString()}</strong></div>
                    <div style={s.td}><StatusBadge status={c.status}/></div>
                    <div style={{ ...s.td, gap:6, flexWrap:'wrap' }}>
                      {c.status === 'pending' && (
                        <>
                          <button onClick={() => handleApprove(c.id)} style={s.approveBtn}><CheckCircle size={13}/> Approve</button>
                          <button onClick={() => handleReject(c.id)} style={s.rejectBtn}><XCircle size={13}/> Reject</button>
                        </>
                      )}
                      {c.status === 'approved' && (
                        <button onClick={() => handleReject(c.id)} style={s.rejectBtn}><XCircle size={13}/> Remove</button>
                      )}
                    </div>
                  </div>
                ))
              }
            </div>
          </div>
        )}

        {/* ALL TRANSACTIONS */}
        {tab === 1 && (
          <div style={s.tableWrap}>
            <div style={{ ...s.thead, gridTemplateColumns:'1.5fr 1.5fr 1fr 1fr 1fr 1fr 1fr' }}>
              {['Reference','Contestant','Voter','Votes','Amount','Method','Status'].map(h => (
                <div key={h} style={s.th}>{h}</div>
              ))}
            </div>
            {loading ? <div style={s.empty}>Loading...</div> : transactions.map(t => (
              <div key={t.id} style={{ ...s.trow, gridTemplateColumns:'1.5fr 1.5fr 1fr 1fr 1fr 1fr 1fr' }}>
                <div style={{ ...s.td, fontSize:11, fontFamily:'monospace' }}>{t.payment_reference?.slice(-12)}</div>
                <div style={s.td}>{t.contestant_name} <span style={{ color:'var(--gold)', fontSize:10 }}>{t.contestant_code}</span></div>
                <div style={{ ...s.td, fontSize:11 }}>{t.voter_name || t.voter_email || 'Anon'}</div>
                <div style={s.td}><strong style={{ color:'var(--gold)' }}>{Number(t.vote_count)?.toLocaleString()}</strong></div>
                <div style={s.td}>{t.currency} {parseFloat(t.amount_paid).toLocaleString()}</div>
                <div style={s.td}><MethodBadge method={t.payment_method}/></div>
                <div style={s.td}><StatusBadge status={t.status}/></div>
              </div>
            ))}
          </div>
        )}

        {/* MANUAL PAYMENTS */}
        {tab === 2 && (
          <div>
            <div style={s.infoBox}>
              📋 These are bank transfer payments awaiting your verification.
              Review the proof screenshot, then confirm or reject each payment.
              Votes are only credited after your confirmation.
            </div>
            {loading ? <div style={s.empty}>Loading...</div> :
            manualPending.length === 0 ? <div style={s.empty}>No manual payments pending</div> :
            manualPending.map(t => (
              <div key={t.id} style={s.manualCard}>
                <div style={s.manualTop}>
                  <div>
                    <div style={{ fontWeight:700, fontSize:16, color:'var(--gold)' }}>{t.contestant_name} <span style={{ fontSize:12, color:'var(--muted)' }}>{t.contestant_code}</span></div>
                    <div style={{ fontSize:13, color:'var(--muted)', marginTop:4 }}>
                      Voter: <strong>{t.voter_name || 'Anonymous'}</strong> | {t.voter_email}
                    </div>
                    <div style={{ fontSize:13, marginTop:4 }}>
                      <strong style={{ color:'var(--gold)' }}>{Number(t.vote_count)?.toLocaleString()} votes</strong> — {t.currency} {parseFloat(t.amount_paid)?.toLocaleString()}
                    </div>
                    <div style={{ fontSize:12, color:'var(--muted)', marginTop:4 }}>
                      Ref: <code style={{ color:'var(--gold)' }}>{t.payment_reference}</code>
                    </div>
                    {t.bank_name && (
                      <div style={{ fontSize:12, color:'var(--muted)', marginTop:4 }}>
                        Bank: {t.bank_name} | Account: {t.bank_account_name}
                        {t.transfer_amount && ` | Claimed: ${t.currency} ${parseFloat(t.transfer_amount).toLocaleString()}`}
                      </div>
                    )}
                    <div style={{ fontSize:11, color:'var(--muted)', marginTop:4 }}>
                      Submitted: {t.proof_uploaded_at ? new Date(t.proof_uploaded_at).toUTCString() : new Date(t.created_at).toUTCString()} (GMT)
                    </div>
                  </div>
                  {t.proof_url && (
                    <div style={{ display:'flex', flexDirection:'column', gap:8, alignItems:'flex-end' }}>
                      <img src={t.proof_url} alt="Payment proof"
                        style={{ width:120, height:100, objectFit:'cover', borderRadius:8, border:'1px solid var(--border)', cursor:'pointer' }}
                        onClick={() => setProofModal(t.proof_url)}
                      />
                      <a href={t.proof_url} target="_blank" rel="noreferrer" style={{ fontSize:11, color:'var(--gold)', display:'flex', alignItems:'center', gap:4 }}>
                        <Eye size={12}/> View Full
                      </a>
                    </div>
                  )}
                </div>
                <div style={s.manualNote}>
                  <input placeholder="Admin note (optional)..." id={`note-${t.id}`}
                    style={{ flex:1, padding:'8px 12px', background:'var(--dark)', border:'1px solid var(--border)', borderRadius:6, color:'var(--text)', fontSize:13, outline:'none' }}/>
                  <button onClick={() => handleConfirmPayment(t.payment_reference, document.getElementById(`note-${t.id}`).value)} style={s.approveBtn}>
                    <CheckCircle size={14}/> Confirm & Credit Votes
                  </button>
                  <button onClick={() => handleRejectPayment(t.payment_reference)} style={s.rejectBtn}>
                    <XCircle size={14}/> Reject
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* NEWSLETTER */}
        {tab === 3 && (
          <div style={s.newsletterPanel}>
            <h3 style={{ fontSize:20, color:'var(--gold)', marginBottom:8 }}>Send Newsletter</h3>
            <p style={{ color:'var(--muted)', fontSize:14, marginBottom:24 }}>
              Send updates to all newsletter subscribers — prize changes, winner announcements, new stages.
            </p>
            <form onSubmit={handleNewsletter} style={{ display:'flex', flexDirection:'column', gap:16 }}>
              <div style={s.nlField}>
                <label style={s.nlLabel}>Subject</label>
                <input required value={newsletter.subject}
                  onChange={e => setNewsletter({...newsletter, subject: e.target.value})}
                  placeholder="e.g. 🏆 Grand Prize Update — Stage 2 Now Open!"
                  style={{ ...s.nlInput }}/>
              </div>
              <div style={s.nlField}>
                <label style={s.nlLabel}>Message Body</label>
                <textarea required rows={8} value={newsletter.body}
                  onChange={e => setNewsletter({...newsletter, body: e.target.value})}
                  placeholder="Write your newsletter message here..."
                  style={{ ...s.nlInput, resize:'vertical' }}/>
              </div>
              <button type="submit" disabled={sending} style={s.nlBtn}>
                <Mail size={16}/> {sending ? 'Sending...' : 'Send to All Subscribers'}
              </button>
            </form>
          </div>
        )}
      </div>

      {/* Proof Modal */}
      {proofModal && (
        <div style={s.overlay} onClick={() => setProofModal(null)}>
          <div style={{ position:'relative' }}>
            <img src={proofModal} alt="Proof" style={{ maxWidth:'90vw', maxHeight:'85vh', borderRadius:12, border:'2px solid var(--gold)' }}/>
            <button onClick={() => setProofModal(null)} style={{ position:'absolute', top:-12, right:-12, background:'var(--red)', border:'none', borderRadius:'50%', width:28, height:28, color:'white', fontWeight:700, cursor:'pointer' }}>✕</button>
          </div>
        </div>
      )}
    </div>
  )
}

function StatusBadge({ status }) {
  const colors = { pending:'#F39C12', approved:'var(--green)', rejected:'var(--red)', success:'var(--green)', failed:'var(--red)', manual_pending:'#F39C12', manual_rejected:'var(--red)', eliminated:'#888', winner:'var(--gold)' }
  return <span style={{ background:`${colors[status]}22`, color:colors[status], padding:'3px 8px', borderRadius:20, fontSize:11, fontWeight:600 }}>{status?.replace('_',' ')}</span>
}
function MethodBadge({ method }) {
  const icons = { card:'💳', momo:'📱', bank_transfer:'🏦', manual:'📋' }
  return <span style={{ fontSize:12 }}>{icons[method]||'💳'} {method?.replace('_',' ')}</span>
}

const s = {
  page: { padding:'40px 24px', minHeight:'100vh' },
  container: { maxWidth:1400, margin:'0 auto' },
  header: { marginBottom:28 },
  title: { fontSize:32, color:'var(--gold)' },
  sub: { color:'var(--muted)', fontSize:13 },
  statsGrid: { display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(180px,1fr))', gap:16, marginBottom:32 },
  statCard: { background:'var(--dark2)', border:'1px solid', borderRadius:14, padding:20, display:'flex', flexDirection:'column', gap:6 },
  tabs: { display:'flex', gap:4, marginBottom:24, borderBottom:'1px solid var(--border)', flexWrap:'wrap' },
  tab: { padding:'10px 18px', background:'none', border:'none', color:'var(--muted)', fontSize:14, fontWeight:500, cursor:'pointer', borderBottom:'2px solid transparent', marginBottom:-1, display:'flex', alignItems:'center', gap:8 },
  tabActive: { color:'var(--gold)', borderBottom:'2px solid var(--gold)' },
  badge: { background:'var(--red)', color:'white', borderRadius:20, padding:'2px 7px', fontSize:11, fontWeight:700 },
  filterRow: { display:'flex', gap:8, marginBottom:20, flexWrap:'wrap' },
  filterBtn: { padding:'7px 14px', background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:20, color:'var(--muted)', fontSize:12, cursor:'pointer' },
  filterActive: { border:'1px solid var(--gold)', color:'var(--gold)', background:'rgba(201,168,76,0.08)' },
  tableWrap: { background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:16, overflow:'hidden' },
  thead: { display:'grid', background:'var(--dark3)', padding:'12px 16px', gap:8 },
  th: { fontSize:11, color:'var(--muted)', fontWeight:600, textTransform:'uppercase', letterSpacing:0.5 },
  trow: { display:'grid', padding:'12px 16px', gap:8, borderTop:'1px solid var(--border)', alignItems:'center' },
  td: { fontSize:12, display:'flex', alignItems:'center', gap:6 },
  thumb: { width:36, height:36, borderRadius:8, objectFit:'cover', border:'1px solid var(--border)' },
  codeBadge: { background:'rgba(201,168,76,0.1)', color:'var(--gold)', padding:'2px 7px', borderRadius:6, fontSize:11, fontWeight:700, fontFamily:'monospace' },
  approveBtn: { padding:'6px 12px', background:'rgba(46,204,113,0.1)', border:'1px solid var(--green)', borderRadius:6, color:'var(--green)', fontSize:11, cursor:'pointer', display:'flex', alignItems:'center', gap:4 },
  rejectBtn: { padding:'6px 12px', background:'rgba(231,76,60,0.1)', border:'1px solid var(--red)', borderRadius:6, color:'var(--red)', fontSize:11, cursor:'pointer', display:'flex', alignItems:'center', gap:4 },
  empty: { textAlign:'center', padding:48, color:'var(--muted)' },
  infoBox: { background:'rgba(201,168,76,0.06)', border:'1px solid var(--border)', borderRadius:10, padding:16, fontSize:13, color:'var(--muted)', marginBottom:20, lineHeight:1.6 },
  manualCard: { background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:14, padding:20, marginBottom:16 },
  manualTop: { display:'flex', justifyContent:'space-between', gap:16, marginBottom:16, flexWrap:'wrap' },
  manualNote: { display:'flex', gap:8, flexWrap:'wrap', alignItems:'center' },
  newsletterPanel: { background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:16, padding:32, maxWidth:700 },
  nlField: { display:'flex', flexDirection:'column', gap:6 },
  nlLabel: { fontSize:13, color:'var(--muted)', fontWeight:500 },
  nlInput: { padding:'12px 14px', background:'var(--dark3)', border:'1px solid var(--border)', borderRadius:8, color:'var(--text)', fontSize:14, outline:'none' },
  nlBtn: { padding:'13px', background:'var(--gold)', color:'var(--black)', border:'none', borderRadius:10, fontWeight:700, fontSize:14, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:8 },
  overlay: { position:'fixed', inset:0, background:'rgba(0,0,0,0.9)', display:'flex', alignItems:'center', justifyContent:'center', zIndex:1000 },
}
