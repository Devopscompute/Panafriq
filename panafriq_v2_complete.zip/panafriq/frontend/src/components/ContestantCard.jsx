import React from 'react'
import { Link } from 'react-router-dom'
import { Star } from 'lucide-react'

export default function ContestantCard({ contestant, rank }) {
  const isTop10  = rank <= 10
  const isTop3   = rank <= 3
  const isWinner = contestant.is_winner || rank === 1
  const medals   = ['🥇','🥈','🥉']

  return (
    <Link to={`/contestant/${contestant.slug}`} style={{ textDecoration:'none' }}>
      <div style={{
        ...s.card,
        ...(isTop10 ? s.goldCard : {}),
        ...(isTop3  ? s.podiumCard : {}),
      }}>
        {/* Crown for winner / #1 */}
        {isWinner && (
          <div style={s.crown}>👑</div>
        )}
        {isTop10 && !isWinner && (
          <div style={s.rankBadge}>{isTop3 ? medals[rank-1] : `#${rank}`}</div>
        )}
        {isTop3 && <div style={s.shimmer}/>}

        <div style={s.imgWrap}>
          <img
            src={contestant.photo_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(contestant.name)}&background=1A1D26&color=C9A84C&size=200`}
            alt={contestant.name} style={s.img}
          />
          <div style={{ ...s.stageBadge, background: contestant.current_stage === 3 ? 'var(--gold)' : contestant.current_stage === 2 ? '#9B59B6' : '#2980B9' }}>
            {contestant.current_stage === 3 ? '🏆 Final' : `Stage ${contestant.current_stage}`}
          </div>
        </div>

        <div style={s.info}>
          <h3 style={{ ...s.name, ...(isTop10 ? { color:'var(--gold)' } : {}) }}>
            {contestant.name}
          </h3>
          {/* Abbreviation badge */}
          <div style={s.abbrev}>{contestant.contestant_code}</div>
          <div style={s.votes}>
            <Star size={13} color="var(--gold)" fill="var(--gold)"/>
            <span style={s.voteNum}>{Number(contestant.total_votes)?.toLocaleString()}</span>
            <span style={s.voteLabel}>votes</span>
          </div>
          <div style={s.flag}>{countryFlag(contestant.country)}</div>
        </div>

        <Link to={`/vote/${contestant.slug}`} style={s.voteBtn} onClick={e => e.stopPropagation()}>
          🗳️ Vote Now
        </Link>
      </div>
    </Link>
  )
}

function countryFlag(c) {
  return c === 'NG' ? '🇳🇬' : c === 'GH' ? '🇬🇭' : c === 'CM' ? '🇨🇲' : '🌍'
}

const s = {
  card: { background:'var(--surface)', border:'1px solid var(--border)', borderRadius:16, overflow:'hidden', transition:'transform .2s, box-shadow .2s', cursor:'pointer', position:'relative', display:'flex', flexDirection:'column' },
  goldCard: { border:'1px solid var(--gold)', boxShadow:'0 0 20px rgba(201,168,76,0.15)' },
  podiumCard: { boxShadow:'0 0 30px rgba(201,168,76,0.3)', transform:'scale(1.01)' },
  crown: { position:'absolute', top:-4, left:'50%', transform:'translateX(-50%)', fontSize:28, zIndex:3, animation:'crownFloat 2s ease-in-out infinite', filter:'drop-shadow(0 0 6px rgba(201,168,76,0.8))' },
  shimmer: { position:'absolute', top:0, left:0, right:0, height:2, background:'linear-gradient(90deg,transparent,var(--gold),transparent)', animation:'shimmer 2s infinite' },
  rankBadge: { position:'absolute', top:10, left:10, background:'var(--gold)', color:'var(--black)', borderRadius:20, padding:'3px 10px', fontSize:11, fontWeight:700, zIndex:2 },
  imgWrap: { position:'relative', aspectRatio:'1', overflow:'hidden' },
  img: { width:'100%', height:'100%', objectFit:'cover', transition:'transform .3s' },
  stageBadge: { position:'absolute', bottom:8, right:8, color:'white', fontSize:10, fontWeight:700, padding:'3px 8px', borderRadius:12 },
  info: { padding:'12px 14px 6px' },
  name: { fontSize:15, fontWeight:700, marginBottom:2, whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' },
  abbrev: { fontSize:11, color:'var(--gold)', fontWeight:700, fontFamily:'monospace', marginBottom:6, background:'rgba(201,168,76,0.1)', borderRadius:4, padding:'2px 6px', width:'fit-content' },
  votes: { display:'flex', alignItems:'center', gap:5, marginBottom:4 },
  voteNum: { fontSize:17, fontWeight:700, color:'var(--gold)' },
  voteLabel: { fontSize:11, color:'var(--muted)' },
  flag: { fontSize:16, marginBottom:4 },
  voteBtn: { display:'block', margin:'0 12px 12px', padding:'9px', background:'var(--gold)', color:'var(--black)', borderRadius:8, textAlign:'center', fontWeight:700, fontSize:12, marginTop:'auto' },
}
