import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { getContests, registerContestant } from '../api'
import { useAuth } from '../contexts/AuthContext'
import toast from 'react-hot-toast'

export default function JoinContest() {
  const nav = useNavigate()
  const { user } = useAuth()
  const [contests, setContests] = useState([])
  const [form, setForm] = useState({ contest: '', bio: '' })
  const [photo, setPhoto] = useState(null)
  const [preview, setPreview] = useState(null)
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!user) { nav('/login'); return }
    getContests().then(r => {
      const list = r.data.results || r.data
      setContests(list)
      if (list.length) setForm(f => ({ ...f, contest: list[0].id }))
    })
  }, [user])

  const handlePhoto = e => {
    const file = e.target.files[0]
    if (!file) return
    setPhoto(file)
    setPreview(URL.createObjectURL(file))
  }

  const handleSubmit = async e => {
    e.preventDefault()
    if (!photo) { toast.error('Please upload a photo'); return }
    setLoading(true)
    const fd = new FormData()
    fd.append('contest', form.contest)
    fd.append('bio', form.bio)
    fd.append('photo', photo)
    try {
      const { data } = await registerContestant(fd)
      toast.success('Application submitted! Awaiting admin approval.')
      nav(`/contestant/${data.slug}`)
    } catch (err) {
      const d = err.response?.data
      toast.error(typeof d === 'object' ? Object.values(d).flat().join(' ') : 'Submission failed')
    } finally { setLoading(false) }
  }

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <h2 style={styles.title}>Join the Contest</h2>
        <p style={styles.sub}>Register your child. Once approved, you'll get a unique voting link to share.</p>
        <form onSubmit={handleSubmit} style={styles.form}>
          <div style={styles.field}>
            <label style={styles.label}>Select Contest</label>
            <select style={styles.input} value={form.contest} onChange={e => setForm({ ...form, contest: e.target.value })}>
              {contests.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>

          <div style={styles.field}>
            <label style={styles.label}>Child's Photo</label>
            <div style={styles.photoUpload} onClick={() => document.getElementById('photoInput').click()}>
              {preview ? (
                <img src={preview} style={styles.preview} alt="preview" />
              ) : (
                <div style={styles.uploadPlaceholder}>
                  <span style={{ fontSize:36 }}>📷</span>
                  <span style={{ fontSize:14, color:'var(--muted)' }}>Click to upload photo</span>
                </div>
              )}
            </div>
            <input id="photoInput" type="file" accept="image/*" onChange={handlePhoto} style={{ display:'none' }} />
          </div>

          <div style={styles.field}>
            <label style={styles.label}>Bio (optional)</label>
            <textarea style={{ ...styles.input, minHeight:100, resize:'vertical' }}
              placeholder="Tell us about your child..."
              value={form.bio} onChange={e => setForm({ ...form, bio: e.target.value })} />
          </div>

          <div style={styles.infoBox}>
            <p>👤 Registering as: <strong>{user?.first_name} {user?.last_name}</strong></p>
            <p>🌍 Country: <strong>{user?.country}</strong></p>
            <p>⏳ Your entry will be reviewed by an admin before going live.</p>
          </div>

          <button type="submit" disabled={loading} style={styles.btn}>
            {loading ? 'Submitting...' : 'Submit Entry'}
          </button>
        </form>
      </div>
    </div>
  )
}

const styles = {
  page: { minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', padding:24 },
  card: { background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:20, padding:40, width:'100%', maxWidth:520 },
  title: { fontSize:28, color:'var(--gold)', marginBottom:6 },
  sub: { color:'var(--muted)', fontSize:14, lineHeight:1.6, marginBottom:28 },
  form: { display:'flex', flexDirection:'column', gap:20 },
  field: { display:'flex', flexDirection:'column', gap:8 },
  label: { fontSize:13, color:'var(--muted)', fontWeight:500 },
  input: { padding:'12px 14px', background:'var(--dark3)', border:'1px solid var(--border)', borderRadius:8, color:'var(--text)', fontSize:14, outline:'none' },
  photoUpload: { background:'var(--dark3)', border:'2px dashed var(--border)', borderRadius:12, aspectRatio:'1', maxWidth:240, cursor:'pointer', overflow:'hidden', display:'flex', alignItems:'center', justifyContent:'center' },
  preview: { width:'100%', height:'100%', objectFit:'cover' },
  uploadPlaceholder: { display:'flex', flexDirection:'column', alignItems:'center', gap:8 },
  infoBox: { background:'rgba(201,168,76,0.06)', border:'1px solid var(--border)', borderRadius:10, padding:16, fontSize:13, color:'var(--muted)', display:'flex', flexDirection:'column', gap:6, lineHeight:1.6 },
  btn: { padding:'14px', background:'var(--gold)', color:'var(--black)', border:'none', borderRadius:10, fontWeight:700, fontSize:15 },
}
