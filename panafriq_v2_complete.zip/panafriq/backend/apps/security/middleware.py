"""
Security middleware stack:
1. SecurityHeadersMiddleware  — injects protective HTTP headers
2. ThreatDetectionMiddleware  — blocks scanners (nmap, nikto, whatweb, etc.)
3. RateLimitMiddleware        — 3-strike IP rate limit on auth endpoints
"""
import re, time, json, logging
from collections import defaultdict
from django.http import JsonResponse
from django.conf import settings
from django.core.mail import send_mail
from django.utils import timezone

logger = logging.getLogger('security')

# ── Threat signatures ────────────────────────────────────────────────
SCANNER_PATTERNS = [
    r'nmap', r'nikto', r'sqlmap', r'masscan', r'zgrab',
    r'whatweb', r'wfuzz', r'dirb', r'gobuster', r'nuclei',
    r'burpsuite', r'owasp', r'metasploit', r'hydra', r'medusa',
    r'python-requests/2\.2[012]', r'go-http-client',
    r'curl/7\.[0-4]', r'libwww-perl', r'wget/',
]
SCANNER_RE = re.compile('|'.join(SCANNER_PATTERNS), re.IGNORECASE)

SUSPICIOUS_PATHS = [
    r'\.php$', r'\.asp$', r'wp-admin', r'wp-login',
    r'phpMyAdmin', r'\.env$', r'\.git/', r'\.htaccess',
    r'/etc/passwd', r'union.*select', r'<script',
    r'eval\(', r'base64_decode', r'\.\./\.\.',
]
SUSPICIOUS_PATH_RE = re.compile('|'.join(SUSPICIOUS_PATHS), re.IGNORECASE)

# In-memory rate limit store (use Redis in production)
_rate_store = defaultdict(list)   # ip -> [timestamps]
_blocked_ips = {}                 # ip -> unblock_time


def _get_ip(request):
    forwarded = request.META.get('HTTP_X_FORWARDED_FOR', '')
    return forwarded.split(',')[0].strip() if forwarded else request.META.get('REMOTE_ADDR', '0.0.0.0')


def _send_security_alert(subject, body):
    try:
        send_mail(
            subject=f'[PanAfriq Security] {subject}',
            message=body,
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[settings.SECURITY_EMAIL],
            fail_silently=True,
        )
    except Exception:
        pass


class SecurityHeadersMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        response = self.get_response(request)
        response['X-Content-Type-Options']    = 'nosniff'
        response['X-Frame-Options']           = 'DENY'
        response['X-XSS-Protection']          = '1; mode=block'
        response['Referrer-Policy']           = 'strict-origin-when-cross-origin'
        response['Permissions-Policy']        = 'geolocation=(), microphone=(), camera=()'
        response['Content-Security-Policy']   = (
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline' https://apis.google.com https://connect.facebook.net; "
            "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
            "font-src 'self' https://fonts.gstatic.com; "
            "img-src 'self' data: https:; "
            "connect-src 'self' https://api.flutterwave.com https://v6.exchangerate-api.com; "
            "frame-ancestors 'none';"
        )
        return response


class ThreatDetectionMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        ip = _get_ip(request)
        ua = request.META.get('HTTP_USER_AGENT', '')
        path = request.path

        # 1. Block known scanner user-agents
        if ua and SCANNER_RE.search(ua):
            self._log_and_alert(ip, ua, path, 'Scanner UA detected')
            return JsonResponse({'error': 'Forbidden'}, status=403)

        # 2. Block suspicious path traversal / injection attempts
        if SUSPICIOUS_PATH_RE.search(path):
            self._log_and_alert(ip, ua, path, 'Suspicious path probe')
            return JsonResponse({'error': 'Not found'}, status=404)

        # 3. Block SQL injection patterns in query string
        qs = request.META.get('QUERY_STRING', '')
        sql_patterns = re.compile(
            r"(union\s+select|drop\s+table|insert\s+into|'--|\bor\b\s+1=1|xp_cmdshell)",
            re.IGNORECASE
        )
        if sql_patterns.search(qs) or sql_patterns.search(path):
            self._log_and_alert(ip, ua, path, 'SQL injection attempt')
            return JsonResponse({'error': 'Bad request'}, status=400)

        return self.get_response(request)

    def _log_and_alert(self, ip, ua, path, reason):
        msg = f"IP: {ip} | Path: {path} | UA: {ua} | Reason: {reason} | Time: {timezone.now().isoformat()}"
        logger.warning(msg)
        _send_security_alert(reason, msg)


class RateLimitMiddleware:
    """3-strike rate limit on authentication endpoints."""
    AUTH_PATHS = ['/api/auth/login/', '/api/auth/register/', '/api/auth/otp/']
    WINDOW = 60 * int(getattr(settings, 'RATE_LIMIT_WINDOW_MINUTES', 15))
    LIMIT  = int(getattr(settings, 'LOGIN_RATE_LIMIT_ATTEMPTS', 3))

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.method == 'POST' and request.path in self.AUTH_PATHS:
            ip = _get_ip(request)
            now = time.time()

            # Check if IP is blocked
            if ip in _blocked_ips and _blocked_ips[ip] > now:
                remaining = int((_blocked_ips[ip] - now) / 60)
                msg = f"Blocked IP {ip} attempted {request.path}"
                logger.warning(msg)
                return JsonResponse(
                    {'error': f'Too many attempts. Try again in {remaining} minutes.'},
                    status=429
                )

            # Clean old timestamps
            _rate_store[ip] = [t for t in _rate_store[ip] if now - t < self.WINDOW]
            _rate_store[ip].append(now)

            if len(_rate_store[ip]) > self.LIMIT:
                block_until = now + self.WINDOW
                _blocked_ips[ip] = block_until
                _send_security_alert(
                    'Rate Limit Exceeded',
                    f"IP {ip} blocked after {self.LIMIT} attempts on {request.path} at {timezone.now().isoformat()}"
                )
                return JsonResponse(
                    {'error': f'Too many attempts. Account locked for {self.RATE_LIMIT_WINDOW_MINUTES} minutes.'},
                    status=429
                )

        return self.get_response(request)
