import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { login } from '../api'
import { useAuth } from '../contexts/AuthContext'
import toast from 'react-hot-toast'

export default function Login() {
  const nav = useNavigate()
  const { loginUser } = useAuth()
  const [form, setForm] = useState({ email:'', password:'' })
  const [loading, setLoading] = useState(false)

  const handleSubmit = async e => {
    e.preventDefault()
    setLoading(true)
    try {
      const { data } = await login(form)
      loginUser(data.user, data.access, data.refresh)
      toast.success(`Welcome back, ${data.user.first_name}!`)
      nav(data.user.is_admin || data.user.is_staff ? '/admin' : '/')
    } catch (err) {
      toast.error(err.response?.data?.non_field_errors?.[0] || 'Login failed')
    } finally { setLoading(false) }
  }

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <h2 style={styles.title}>Welcome Back</h2>
        <p style={styles.sub}>Login to your PanAfriq account</p>
        <form onSubmit={handleSubmit} style={styles.form}>
          <div style={styles.field}>
            <label style={styles.label}>Email</label>
            <input type="email" required style={styles.input} value={form.email}
              onChange={e => setForm({ ...form, email: e.target.value })} />
          </div>
          <div style={styles.field}>
            <label style={styles.label}>Password</label>
            <input type="password" required style={styles.input} value={form.password}
              onChange={e => setForm({ ...form, password: e.target.value })} />
          </div>
          <button type="submit" disabled={loading} style={styles.btn}>
            {loading ? 'Logging in...' : 'Login'}
          </button>
        </form>
        <p style={styles.foot}>No account? <Link to="/register" style={{ color:'var(--gold)' }}>Register here</Link></p>
      </div>
    </div>
  )
}

const styles = {
  page: { minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', padding:24 },
  card: { background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:20, padding:40, width:'100%', maxWidth:420 },
  title: { fontSize:28, color:'var(--gold)', marginBottom:6 },
  sub: { color:'var(--muted)', fontSize:14, marginBottom:28 },
  form: { display:'flex', flexDirection:'column', gap:18 },
  field: { display:'flex', flexDirection:'column', gap:6 },
  label: { fontSize:13, color:'var(--muted)', fontWeight:500 },
  input: { padding:'13px 14px', background:'var(--dark3)', border:'1px solid var(--border)', borderRadius:8, color:'var(--text)', fontSize:14, outline:'none' },
  btn: { padding:'14px', background:'var(--gold)', color:'var(--black)', border:'none', borderRadius:10, fontWeight:700, fontSize:15 },
  foot: { textAlign:'center', marginTop:20, color:'var(--muted)', fontSize:14 },
}
