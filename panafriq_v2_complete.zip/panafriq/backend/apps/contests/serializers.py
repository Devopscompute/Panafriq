from rest_framework import serializers
from .models import Contest, Contestant, Vote
from apps.users.serializers import UserSerializer


class ContestSerializer(serializers.ModelSerializer):
    class Meta:
        model = Contest
        fields = '__all__'


class ContestantSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    profile_url = serializers.SerializerMethodField()
    vote_url = serializers.SerializerMethodField()

    class Meta:
        model = Contestant
        fields = ['id', 'user', 'contest', 'contestant_code', 'slug', 'bio', 'photo',
                  'total_votes', 'stage_1_votes', 'stage_2_votes', 'stage_3_votes',
                  'current_stage', 'status', 'rank', 'profile_url', 'vote_url', 'created_at']
        read_only_fields = ['id', 'contestant_code', 'slug', 'total_votes', 'rank', 'created_at']

    def get_profile_url(self, obj):
        return obj.get_profile_url()

    def get_vote_url(self, obj):
        return obj.get_vote_url()


class ContestantCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Contestant
        fields = ['contest', 'bio', 'photo']

    def create(self, validated_data):
        user = self.context['request'].user
        contest = validated_data['contest']
        count = Contestant.objects.filter(contest=contest).count() + 1
        code = f"CK{count:04d}"
        contestant = Contestant.objects.create(
            user=user, contestant_code=code, **validated_data
        )
        return contestant


class LeaderboardSerializer(serializers.ModelSerializer):
    name = serializers.SerializerMethodField()
    photo_url = serializers.SerializerMethodField()
    country = serializers.SerializerMethodField()

    class Meta:
        model = Contestant
        fields = ['id', 'slug', 'contestant_code', 'name', 'photo_url',
                  'total_votes', 'stage_1_votes', 'stage_2_votes', 'stage_3_votes',
                  'rank', 'current_stage', 'country']

    def get_name(self, obj):
        return obj.user.get_full_name()

    def get_photo_url(self, obj):
        request = self.context.get('request')
        if obj.photo and request:
            return request.build_absolute_uri(obj.photo.url)
        return None

    def get_country(self, obj):
        return obj.user.country
