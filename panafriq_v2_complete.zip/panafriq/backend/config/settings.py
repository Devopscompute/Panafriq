from pathlib import Path
from decouple import config
from datetime import timedelta

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = config('SECRET_KEY', default='django-insecure-change-me')
DEBUG = config('DEBUG', default=True, cast=bool)
ALLOWED_HOSTS = config('ALLOWED_HOSTS', default='*').split(',')

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django.contrib.sites',
    # Third party
    'rest_framework',
    'rest_framework_simplejwt',
    'corsheaders',
    'django_filters',
    'axes',
    'django_celery_beat',
    # Apps
    'apps.users',
    'apps.contests',
    'apps.payments',
    'apps.security',
    'apps.notifications',
]

MIDDLEWARE = [
    'apps.security.middleware.SecurityHeadersMiddleware',
    'apps.security.middleware.ThreatDetectionMiddleware',
    'apps.security.middleware.RateLimitMiddleware',
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'corsheaders.middleware.CorsMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'axes.middleware.AxesMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'config.urls'
AUTH_USER_MODEL = 'users.User'
SITE_ID = 1

TEMPLATES = [{
    'BACKEND': 'django.template.backends.django.DjangoTemplates',
    'DIRS': [],
    'APP_DIRS': True,
    'OPTIONS': {'context_processors': [
        'django.template.context_processors.debug',
        'django.template.context_processors.request',
        'django.contrib.auth.context_processors.auth',
        'django.contrib.messages.context_processors.messages',
    ]},
}]

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': config('DB_NAME', default='panafriq_db'),
        'USER': config('DB_USER', default='root'),
        'PASSWORD': config('DB_PASSWORD', default=''),
        'HOST': config('DB_HOST', default='localhost'),
        'PORT': config('DB_PORT', default='3306'),
        'OPTIONS': {
            'charset': 'utf8mb4',
            'init_command': "SET sql_mode='STRICT_TRANS_TABLES'",
        },
    }
}

AUTHENTICATION_BACKENDS = [
    'axes.backends.AxesStandaloneBackend',
    'django.contrib.auth.backends.ModelBackend',
]

REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework_simplejwt.authentication.JWTAuthentication',
    ),
    'DEFAULT_PERMISSION_CLASSES': (
        'rest_framework.permissions.IsAuthenticatedOrReadOnly',
    ),
    'DEFAULT_FILTER_BACKENDS': ['django_filters.rest_framework.DjangoFilterBackend'],
    'DEFAULT_PAGINATION_CLASS': 'rest_framework.pagination.PageNumberPagination',
    'DEFAULT_THROTTLE_CLASSES': [
        'rest_framework.throttling.AnonRateThrottle',
        'rest_framework.throttling.UserRateThrottle',
    ],
    'DEFAULT_THROTTLE_RATES': {
        'anon': '60/minute',
        'user': '200/minute',
        'login': '5/minute',
        'otp':   '3/minute',
    },
    'PAGE_SIZE': 20,
    'EXCEPTION_HANDLER': 'apps.security.exceptions.custom_exception_handler',
}

SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(hours=24),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=7),
    'ROTATE_REFRESH_TOKENS': True,
    'BLACKLIST_AFTER_ROTATION': True,
    'ALGORITHM': 'HS256',
    'AUTH_HEADER_TYPES': ('Bearer',),
}

# Django-axes brute force protection
AXES_FAILURE_LIMIT = 3
AXES_COOLOFF_TIME = timedelta(hours=1)
AXES_LOCKOUT_CALLABLE = 'apps.security.views.lockout_response'
AXES_RESET_ON_SUCCESS = True

CORS_ALLOWED_ORIGINS = config('CORS_ORIGINS', default='http://localhost:5173').split(',')
CORS_ALLOW_CREDENTIALS = True

# Security headers
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_BROWSER_XSS_FILTER   = True
X_FRAME_OPTIONS              = 'DENY'
if not DEBUG:
    SECURE_SSL_REDIRECT          = True
    SECURE_HSTS_SECONDS          = 31536000
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
    SESSION_COOKIE_SECURE        = True
    CSRF_COOKIE_SECURE           = True

STATIC_URL  = '/static/'
MEDIA_URL   = '/media/'
MEDIA_ROOT  = BASE_DIR / 'media'
STATIC_ROOT = BASE_DIR / 'staticfiles'

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'   # Always store in UTC — display in frontend as GMT
USE_I18N = True
USE_TZ   = True

# Flutterwave
FLUTTERWAVE_SECRET_KEY  = config('FLUTTERWAVE_SECRET_KEY', default='')
FLUTTERWAVE_PUBLIC_KEY  = config('FLUTTERWAVE_PUBLIC_KEY', default='')
FLUTTERWAVE_SECRET_HASH = config('FLUTTERWAVE_SECRET_HASH', default='')

# Google & Facebook OAuth
GOOGLE_CLIENT_ID     = config('GOOGLE_CLIENT_ID', default='')
GOOGLE_CLIENT_SECRET = config('GOOGLE_CLIENT_SECRET', default='')
FACEBOOK_APP_ID      = config('FACEBOOK_APP_ID', default='')
FACEBOOK_APP_SECRET  = config('FACEBOOK_APP_SECRET', default='')

# Exchange Rate
EXCHANGE_RATE_API_KEY = config('EXCHANGE_RATE_API_KEY', default='')

# Frontend
FRONTEND_URL  = config('FRONTEND_URL', default='http://localhost:5173')

# Email
EMAIL_BACKEND       = config('EMAIL_BACKEND', default='django.core.mail.backends.console.EmailBackend')
EMAIL_HOST          = config('EMAIL_HOST', default='smtp.gmail.com')
EMAIL_PORT          = config('EMAIL_PORT', default=587, cast=int)
EMAIL_USE_TLS       = True
EMAIL_HOST_USER     = config('EMAIL_HOST_USER', default='')
EMAIL_HOST_PASSWORD = config('EMAIL_HOST_PASSWORD', default='')
DEFAULT_FROM_EMAIL  = config('DEFAULT_FROM_EMAIL', default='PanAfriq <noreply@panafriq.com>')
SECURITY_EMAIL      = config('SECURITY_EMAIL', default='harivanojong2018@gmail.com')
ADMIN_EMAIL         = config('ADMIN_EMAIL', default='harivanojong2018@gmail.com')

# Celery
CELERY_BROKER_URL         = config('REDIS_URL', default='redis://localhost:6379/0')
CELERY_RESULT_BACKEND     = config('REDIS_URL', default='redis://localhost:6379/0')
CELERY_TIMEZONE           = 'UTC'
CELERY_BEAT_SCHEDULER     = 'django_celery_beat.schedulers:DatabaseScheduler'

# Vote pricing
VOTE_PRICE_NGN = 50

# Contest stages
STAGE_1_MIN_VOTES = 100
STAGE_2_MIN_VOTES = 600   # Updated from 400

# OTP
OTP_EXPIRY_MINUTES = 10

# Rate limiting
LOGIN_RATE_LIMIT_ATTEMPTS = 3
RATE_LIMIT_WINDOW_MINUTES = 15

# Honeypot admin path
ADMIN_HONEYPOT_PATH = config('ADMIN_HONEYPOT_PATH', default='honeypot-route')
REAL_ADMIN_PATH     = config('REAL_ADMIN_PATH',     default='panafriq-secure-admin-2025')
