// Re-export JoinContest for backward compat
export { default } from './JoinContest'
