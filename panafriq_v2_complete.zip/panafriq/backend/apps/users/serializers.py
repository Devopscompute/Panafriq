from rest_framework import serializers
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate
from django.utils import timezone
from .models import User, VoterSession


class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, min_length=8)
    confirm_password = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email', 'password', 'confirm_password',
                  'phone', 'country', 'date_of_birth', 'whatsapp_number']

    def validate(self, data):
        if data['password'] != data['confirm_password']:
            raise serializers.ValidationError("Passwords do not match.")
        if data.get('date_of_birth'):
            today = timezone.now().date()
            age = (today - data['date_of_birth']).days // 365
            if age < 16:
                raise serializers.ValidationError("You must be at least 16 years old to register.")
        return data

    def create(self, validated_data):
        validated_data.pop('confirm_password')
        email = validated_data['email']
        validated_data['username'] = email.split('@')[0]
        user = User.objects.create_user(**validated_data)
        return user


class LoginSerializer(serializers.Serializer):
    email = serializers.EmailField()
    password = serializers.CharField()

    def validate(self, data):
        user = authenticate(username=data['email'], password=data['password'])
        if not user:
            raise serializers.ValidationError("Invalid credentials.")
        if not user.is_active:
            raise serializers.ValidationError("Account is disabled.")
        data['user'] = user
        return data


class UserSerializer(serializers.ModelSerializer):
    age = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ['id', 'first_name', 'last_name', 'email', 'phone', 'country',
                  'date_of_birth', 'age', 'profile_picture', 'is_verified', 'is_admin',
                  'whatsapp_number', 'created_at']
        read_only_fields = ['id', 'is_verified', 'is_admin', 'created_at']

    def get_age(self, obj):
        return obj.get_age()


class VoterSessionSerializer(serializers.ModelSerializer):
    class Meta:
        model = VoterSession
        fields = ['session_token', 'email', 'date_of_birth', 'age_verified']
        read_only_fields = ['session_token', 'age_verified']
