import React, { useEffect, useState } from 'react'
import { getLeaderboard, getContests } from '../api'
import ContestantCard from '../components/ContestantCard'
import { Trophy, RefreshCw } from 'lucide-react'

export default function Leaderboard() {
  const [contestants, setContestants] = useState([])
  const [contests, setContests] = useState([])
  const [selectedContest, setSelectedContest] = useState('')
  const [selectedStage, setSelectedStage] = useState('')
  const [loading, setLoading] = useState(true)
  const [lastUpdated, setLastUpdated] = useState(null)

  const fetchData = async () => {
    setLoading(true)
    try {
      const params = {}
      if (selectedContest) params.contest = selectedContest
      if (selectedStage) params.current_stage = selectedStage
      const r = await getLeaderboard(params)
      setContestants(r.data.results || r.data)
      setLastUpdated(new Date())
    } finally { setLoading(false) }
  }

  useEffect(() => {
    getContests().then(r => setContests(r.data.results || r.data))
  }, [])

  useEffect(() => { fetchData() }, [selectedContest, selectedStage])

  // Auto-refresh every 30s
  useEffect(() => {
    const id = setInterval(fetchData, 30000)
    return () => clearInterval(id)
  }, [selectedContest, selectedStage])

  const top3 = contestants.slice(0, 3)
  const rest  = contestants.slice(3)

  return (
    <div style={styles.page}>
      <div style={styles.header}>
        <div style={styles.headerInner}>
          <Trophy size={32} color="var(--gold)" />
          <div>
            <h1 style={styles.title}>Live Leaderboard</h1>
            {lastUpdated && <p style={styles.updated}>Updated {lastUpdated.toLocaleTimeString()}</p>}
          </div>
          <button onClick={fetchData} style={styles.refreshBtn} disabled={loading}>
            <RefreshCw size={16} style={{ animation: loading ? 'spin 1s linear infinite' : 'none' }} />
          </button>
        </div>

        <div style={styles.filters}>
          <select style={styles.select} value={selectedContest} onChange={e => setSelectedContest(e.target.value)}>
            <option value="">All Contests</option>
            {contests.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
          <select style={styles.select} value={selectedStage} onChange={e => setSelectedStage(e.target.value)}>
            <option value="">All Stages</option>
            <option value="1">Stage 1</option>
            <option value="2">Stage 2</option>
            <option value="3">Finals</option>
          </select>
        </div>
      </div>

      {/* Podium — Top 3 */}
      {!loading && top3.length >= 3 && (
        <div style={styles.podiumSection}>
          <div style={styles.podium}>
            {/* 2nd place */}
            <PodiumCard contestant={top3[1]} rank={2} height={160} />
            {/* 1st place */}
            <PodiumCard contestant={top3[0]} rank={1} height={200} />
            {/* 3rd place */}
            <PodiumCard contestant={top3[2]} rank={3} height={130} />
          </div>
        </div>
      )}

      {/* Gold top 10 banner */}
      <div style={styles.goldBanner}>
        ✨ Top 10 contestants glow in gold — Rally your votes to reach the top!
      </div>

      {/* All contestants grid */}
      {loading ? (
        <div style={styles.loading}>Loading leaderboard...</div>
      ) : (
        <div style={styles.grid}>
          {contestants.map((c, i) => (
            <ContestantCard key={c.id} contestant={c} rank={i + 1} />
          ))}
        </div>
      )}
    </div>
  )
}

function PodiumCard({ contestant, rank, height }) {
  const medals = ['🥇', '🥈', '🥉']
  const colors = ['var(--gold)', '#C0C0C0', '#CD7F32']
  return (
    <div style={{ ...styles.podiumCard, alignSelf:'flex-end' }}>
      <img src={contestant.photo_url || '/placeholder.jpg'} style={{ ...styles.podiumImg, border:`3px solid ${colors[rank-1]}` }} alt="" />
      <div style={{ fontSize:28, marginBottom:4 }}>{medals[rank-1]}</div>
      <div style={{ fontWeight:700, fontSize:14, color: colors[rank-1], textAlign:'center', maxWidth:120 }}>{contestant.name?.split(' ')[0]}</div>
      <div style={{ fontSize:13, color:'var(--muted)' }}>{contestant.contestant_code}</div>
      <div style={{ fontWeight:800, fontSize:18, color: colors[rank-1] }}>{contestant.total_votes?.toLocaleString()}</div>
      <div style={{ ...styles.podiumBase, height, background:`linear-gradient(180deg, ${colors[rank-1]}22, ${colors[rank-1]}44)`, border:`1px solid ${colors[rank-1]}44` }}>
        <span style={{ fontWeight:900, fontSize:28, color: colors[rank-1], opacity:0.5 }}>{rank}</span>
      </div>
    </div>
  )
}

const styles = {
  page: { padding:'40px 24px', maxWidth:1200, margin:'0 auto' },
  header: { marginBottom:40 },
  headerInner: { display:'flex', alignItems:'center', gap:16, marginBottom:20 },
  title: { fontSize:36, color:'var(--gold)' },
  updated: { fontSize:12, color:'var(--muted)', marginTop:2 },
  refreshBtn: { marginLeft:'auto', background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:8, padding:10, color:'var(--muted)', cursor:'pointer' },
  filters: { display:'flex', gap:12, flexWrap:'wrap' },
  select: { padding:'10px 14px', background:'var(--dark2)', border:'1px solid var(--border)', borderRadius:8, color:'var(--text)', fontSize:14, outline:'none' },
  podiumSection: { marginBottom:40 },
  podium: { display:'flex', justifyContent:'center', alignItems:'flex-end', gap:16 },
  podiumCard: { display:'flex', flexDirection:'column', alignItems:'center', gap:4 },
  podiumImg: { width:80, height:80, borderRadius:'50%', objectFit:'cover', marginBottom:8 },
  podiumBase: { width:120, borderRadius:'8px 8px 0 0', display:'flex', alignItems:'center', justifyContent:'center', marginTop:8 },
  goldBanner: { background:'linear-gradient(90deg, rgba(201,168,76,0.08), rgba(201,168,76,0.15), rgba(201,168,76,0.08))', border:'1px solid var(--border)', borderRadius:10, padding:'12px 20px', fontSize:13, color:'var(--gold)', textAlign:'center', marginBottom:32 },
  grid: { display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(200px,1fr))', gap:20 },
  loading: { textAlign:'center', padding:80, color:'var(--muted)' },
}
