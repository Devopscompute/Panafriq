import os
from celery import Celery

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')

app = Celery('panafriq')
app.config_from_object('django.conf:settings', namespace='CELERY')
app.autodiscover_tasks()

# Scheduled tasks
from celery.schedules import crontab

app.conf.beat_schedule = {
    'process-stage-eliminations': {
        'task': 'apps.contests.tasks.process_stage_eliminations',
        'schedule': crontab(minute='*/30'),  # every 30 minutes
    },
    'update-rankings': {
        'task': 'apps.contests.tasks.update_rankings',
        'schedule': crontab(minute='*/5'),   # every 5 minutes
    },
}
