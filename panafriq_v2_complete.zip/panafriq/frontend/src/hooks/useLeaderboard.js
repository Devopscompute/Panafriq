import { useState, useEffect, useCallback } from 'react'
import { getLeaderboard } from '../api'

export default function useLeaderboard(params = {}, autoRefreshMs = 30000) {
  const [data, setData]       = useState([])
  const [loading, setLoading] = useState(true)
  const [lastUpdated, setLastUpdated] = useState(null)

  const fetch = useCallback(async () => {
    try {
      const r = await getLeaderboard(params)
      setData(r.data.results || r.data)
      setLastUpdated(new Date())
    } catch {} finally { setLoading(false) }
  }, [JSON.stringify(params)])

  useEffect(() => {
    fetch()
    const id = setInterval(fetch, autoRefreshMs)
    return () => clearInterval(id)
  }, [fetch, autoRefreshMs])

  return { data, loading, lastUpdated, refresh: fetch }
}
