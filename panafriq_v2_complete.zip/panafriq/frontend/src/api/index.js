import axios from 'axios'

const api = axios.create({ baseURL: '/api', timeout: 20000 })

api.interceptors.request.use(cfg => {
  const token = localStorage.getItem('access_token')
  if (token) cfg.headers.Authorization = `Bearer ${token}`
  return cfg
})

api.interceptors.response.use(
  r => r,
  async err => {
    if (err.response?.status === 401) {
      const refresh = localStorage.getItem('refresh_token')
      if (refresh) {
        try {
          const { data } = await axios.post('/api/auth/token/refresh/', { refresh })
          localStorage.setItem('access_token', data.access)
          err.config.headers.Authorization = `Bearer ${data.access}`
          return api.request(err.config)
        } catch { localStorage.clear() }
      }
    }
    return Promise.reject(err)
  }
)

export default api

// Auth
export const register           = d => api.post('/auth/register/', d, { headers: { 'Content-Type': 'multipart/form-data' } })
export const login              = d => api.post('/auth/login/', d)
export const getProfile         = () => api.get('/auth/profile/')
export const updateProfile      = d => api.patch('/auth/profile/', d, { headers: { 'Content-Type': 'multipart/form-data' } })
export const verifyOTP          = otp => api.post('/auth/otp/verify/', { otp })
export const resendOTP          = () => api.post('/auth/otp/resend/')
export const setupTOTP          = () => api.get('/auth/totp/setup/')
export const confirmTOTP        = code => api.post('/auth/totp/setup/', { code })
export const googleSSO          = token => api.post('/auth/sso/google/', { token })
export const facebookSSO        = token => api.post('/auth/sso/facebook/', { token })
export const createVoterSession = d => api.post('/auth/voter-session/', d)

// Contests
export const getContests         = () => api.get('/contests/')
export const getLeaderboard      = p => api.get('/contests/leaderboard/', { params: p })
export const getContestant       = slug => api.get(`/contests/contestant/${slug}/`)
export const registerContestant  = d => api.post('/contests/register/', d, { headers: { 'Content-Type': 'multipart/form-data' } })
export const adminGetContestants = p => api.get('/contests/admin/contestants/', { params: p })
export const approveContestant   = id => api.post(`/contests/admin/contestants/${id}/approve/`)
export const rejectContestant    = id => api.post(`/contests/admin/contestants/${id}/reject/`)

// Payments
export const getPricing        = (country, votes) => api.get('/payments/pricing/', { params: { country, votes } })
export const initPayment       = d => api.post('/payments/initiate/', d)
export const uploadProof       = (ref, fd) => api.post(`/payments/proof/${ref}/`, fd, { headers: { 'Content-Type': 'multipart/form-data' } })
export const verifyPayment     = ref => api.get('/payments/verify/', { params: { reference: ref } })
export const confirmManual     = (ref, data) => api.post(`/payments/manual/confirm/${ref}/`, data)
export const rejectManual      = (ref, reason) => api.post(`/payments/manual/reject/${ref}/`, { reason })
export const adminTransactions = p => api.get('/payments/admin/transactions/', { params: p })

// Newsletter
export const subscribe   = email => api.post('/notifications/subscribe/', { email })
export const sendNewsletter = d => api.post('/notifications/send/', d)
